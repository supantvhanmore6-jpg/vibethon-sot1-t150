# AIML Quest Design System

## Purpose & Tone
Futuristic gamified AI/ML learning platform. Tone: energetic, premium, cyberpunk. Emotion: excitement, mastery, progression. Aesthetic: neon glow meets minimalism, game UI meets education dashboard.

## Palette

| Token | OKLCH | Hex | Usage |
|---|---|---|---|
| **Background** | 0.07 0 0 | #0B1026 | Deep void, primary surface |
| **Card** | 0.12 0.01 280 | #1A1A3E | Glassmorphic cards, elevated zones |
| **Foreground** | 0.96 0 0 | #F5F5F5 | Primary text, high contrast |
| **Primary** | 0.62 0.24 287 | #7C3AED | CTAs, active states, hero accents |
| **Accent** | 0.84 0.17 195 | #22D3EE | Highlights, borders, secondary CTAs, glow |
| **Muted** | 0.18 0.01 280 | #1F1F42 | Disabled, subtle backgrounds |
| **Border** | 0.18 0.04 287 | #2A2A4E | Card borders, subtle dividers |
| **Ring** | 0.84 0.17 195 | #22D3EE | Focus rings, accent shadows |

## Typography

| Layer | Font | Usage | Scale |
|---|---|---|---|
| Display | Bricolage Grotesque | H1–H2, hero headings, brand | 32–48px, weight 700–800 |
| Body | General Sans | P, labels, UI text, descriptions | 14–16px, weight 400–500 |
| Mono | JetBrains Mono | Code blocks, terminal, tech accents | 12–14px, weight 400 |

## Shape Language
- **Cards**: 14px (rounded-2xl) — glassmorphic with backdrop blur
- **Buttons**: 8px (rounded-lg) — compact, snappy
- **Inputs**: 8px (rounded-lg) — consistent with buttons
- **Icons**: Full rounded on badges, 4px on secondary elements

## Elevation & Depth

| Level | Surface | Border | Shadow |
|---|---|---|---|
| Base | bg-background | none | none |
| Elevated | bg-card/30 + backdrop-blur-md | border-border/30 | glow-primary/25 |
| Interactive | bg-card/50 | border-accent/50 on hover | glow-lg on hover |
| Focus | bg-card/70 | border-accent/70 | glow-cyan-lg |

## Structural Zones

| Zone | Background | Border | Notes |
|---|---|---|---|
| Header/Nav | bg-background/80 backdrop-blur | border-b border-border/30 | Sticky, glass effect |
| Hero | bg-background, radial gradient accent | none | Full bleed, dark void |
| Content Sections | bg-background | border-t border-border/20 | Alternating card density |
| Card/Module | glass, 0.12 card bg | border-border/30 | Hover: border-accent/50 |
| Footer | bg-muted/20 | border-t border-border/20 | Subtle, low visual weight |

## Component Patterns

**Neon Buttons**: `.neon-btn-primary` (purple glow), `.neon-btn-accent` (cyan glow), `.neon-btn-secondary` (glass border). Hover: shadow increases, slight scale effect. Transition: 300ms.

**Glass Cards**: `.glass` (bg-card/30, backdrop-blur-md) or `.card-interactive` (glass + rounded-2xl + hover shadow glow). Border adds depth without weight.

**Text Glow**: `.text-glow` for gradient hero text. Primary → Accent gradient for brand emphasis.

**Interactive Hover**: All clickable elements: `transition-smooth` (300ms ease), scale-95 on active, shadow glow on hover.

## Motion & Animation

| Animation | Duration | Easing | Use |
|---|---|---|---|
| fade-in | 300ms | ease-out | Page transitions |
| slide-in-up | 400ms | ease-out | Card entrance |
| slide-in-down | 400ms | ease-out | Modal/overlay entrance |
| pulse-glow | 2s | ease-in-out | Continuous accent glow |
| hover-scale | 250ms | ease-out | Button/card hover |

All interactive elements: `transition-smooth` base, 300ms default.

## Constraints

- **No full-page gradients** — use layered composition (background + card + glow shadows)
- **Dark mode only** — designed exclusively for dark theme, no light mode variant
- **Neon glow sparingly** — glow on CTAs + accent borders only, never on every element
- **Glassmorphism base** — every elevated surface uses backdrop blur + subtle transparency
- **Accessible contrast** — Foreground (0.96 L) on Background (0.07 L) = 0.89 lightness difference (AA+++). Accent on dark surfaces verified for readability.
- **Framer Motion for complex animations** — CSS for simple transitions, Framer for staggered sequences + game interactions

## Signature Detail

**Neon border glow**: Cards and CTAs feature a subtle cyan glow border on hover (border-accent/50 + shadow-glow-cyan/30). This reinforces the cyberpunk aesthetic without overwhelming. The purple primary glow (primary/40) on buttons creates visual hierarchy — purple for primary actions, cyan for secondary/accent. Particles in background (subtle, opacity 20–30%, slow drift) add movement without distraction.

## Browser Support
- Modern evergreen (Chrome, Firefox, Safari, Edge)
- CSS custom properties, backdrop-filter, oklch color space required
- Responsive: mobile-first, `sm` (640px), `md` (768px), `lg` (1024px), `xl` (1280px)
