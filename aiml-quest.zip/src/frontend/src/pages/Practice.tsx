import {
  Activity,
  ArrowRight,
  BarChart3,
  BookOpen,
  Brain,
  CheckCircle2,
  ChevronRight,
  Code2,
  Cpu,
  Database,
  ExternalLink,
  Lightbulb,
  Play,
  RefreshCw,
  Target,
  Zap,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useRef, useState } from "react";
import ParticleBackground from "../components/ParticleBackground";

type Difficulty = "All" | "Easy" | "Medium" | "Hard";

// ─── Code snippets ───────────────────────────────────────────────────────────

const CODE_HOUSE_PRICES = [
  "# Predict House Prices with Linear Regression",
  "import numpy as np",
  "from sklearn.linear_model import LinearRegression",
  "from sklearn.model_selection import train_test_split",
  "from sklearn.metrics import r2_score",
  "",
  "# Training data: [size_sqft, bedrooms, age_years]",
  "X = [[1000, 2, 10], [1500, 3, 5], [2000, 4, 8],",
  "     [2500, 5, 3], [1200, 2, 15], [1800, 3, 7]]",
  "y = [200000, 280000, 350000, 420000, 220000, 310000]",
  "",
  "# Split into train/test sets",
  "X_train, X_test, y_train, y_test = train_test_split(",
  "    X, y, test_size=0.2, random_state=42)",
  "",
  "# Train model",
  "model = LinearRegression()",
  "model.fit(X_train, y_train)",
  "",
  "# Predict and evaluate",
  "predictions = model.predict(X_test)",
  "score = r2_score(y_test, predictions)",
  'print(f"R² Score: {score:.3f}")',
  "",
  "# New house: 1,750 sqft, 3 beds, 6 years old",
  "new_house = [[1750, 3, 6]]",
  "price = model.predict(new_house)[0]",
  'print(f"Predicted price: ${price:,.0f}")',
].join("\n");

const OUTPUT_HOUSE_PRICES = [
  "Training Linear Regression model...",
  "Features: size_sqft, bedrooms, age_years",
  "Training samples: 4  |  Test samples: 2",
  "",
  "Model Coefficients:",
  "  size_sqft : 124.50",
  "  bedrooms  :  8200.00",
  "  age_years :  -500.00",
  "  intercept :  45000.00",
  "",
  "Evaluation:",
  "  R² Score : 0.982",
  "  MSE      : 42,500,000",
  "",
  "Prediction Results:",
  "┌─────────────────────────────────────┐",
  "│  Input  │ Size: 1750 sqft, 3 beds  │",
  "│         │ Age : 6 years            │",
  "├─────────────────────────────────────┤",
  "│  Output │ Predicted Price:         │",
  "│         │ $318,500                 │",
  "└─────────────────────────────────────┘",
  "",
  "✓ Model training complete!",
].join("\n");

const CODE_SPAM_DETECTOR = [
  "# Spam Detector with Naive Bayes",
  "from sklearn.naive_bayes import MultinomialNB",
  "from sklearn.feature_extraction.text import CountVectorizer",
  "from sklearn.pipeline import Pipeline",
  "from sklearn.metrics import classification_report",
  "",
  "# Training data",
  "emails = [",
  '    "Win a FREE iPhone now!! Click here!!!",',
  '    "Meeting scheduled for 3pm tomorrow",',
  '    "Claim your $1000 prize money today",',
  '    "Project deadline is this Friday",',
  '    "Congratulations! You have been selected",',
  '    "Can you review my pull request?",',
  "]",
  'labels = ["spam", "ham", "spam", "ham", "spam", "ham"]',
  "",
  "# Build pipeline",
  "pipeline = Pipeline([",
  "    ('vectorizer', CountVectorizer(stop_words='english')),",
  "    ('classifier', MultinomialNB(alpha=0.1))",
  "])",
  "",
  "pipeline.fit(emails, labels)",
  "",
  "# Test new emails",
  "test_emails = [",
  '    "You won a lottery prize claim now",',
  '    "Let us sync up this afternoon",',
  "]",
  "results = pipeline.predict(test_emails)",
  "for email, label in zip(test_emails, results):",
  '    print(f"[{label.upper():4}] {email}")',
].join("\n");

const OUTPUT_SPAM_DETECTOR = [
  "Training Naive Bayes classifier...",
  "Vocabulary size: 34 unique tokens",
  "Training samples: 6",
  "",
  "Classification Results:",
  "  [SPAM] You won a lottery prize claim now",
  "  [HAM ] Let us sync up this afternoon",
  "",
  "Confidence Scores:",
  "  Email 1 → spam: 94.2%  |  ham:  5.8%",
  "  Email 2 → ham : 88.7%  |  spam: 11.3%",
  "",
  "Model Performance (cross-val):",
  "  Precision: 0.91",
  "  Recall   : 0.89",
  "  F1-Score : 0.90",
  "",
  "✓ Spam detector ready!",
].join("\n");

const CODE_CHATBOT = [
  "# Intent-Based Chatbot with Pattern Matching",
  "import re",
  "",
  "# Intent definitions",
  "INTENTS = {",
  '    r"hello|hi|hey|greetings": "Hello! I\'m your AI tutor. Ask me about AI or ML!",',
  '    r"what.*(is|are).*(ai|artificial intelligence)":',
  '        "AI is the simulation of human intelligence — machines that learn,",',
  '        " reason, and solve problems like humans.",',
  '    r"what.*(is|are).*(ml|machine learning)":',
  '        "ML is a subset of AI where systems learn patterns from data",',
  '        " without being explicitly programmed.",',
  '    r"deep learning|neural network":',
  '        "Deep Learning uses multi-layer neural networks to learn complex",',
  '        " representations from raw data like images or text.",',
  '    r"bye|goodbye|exit": "Goodbye! Keep learning! 🚀",',
  "}",
  "",
  "def chatbot_response(user_input: str) -> str:",
  "    text = user_input.lower().strip()",
  "    for pattern, response in INTENTS.items():",
  "        if re.search(pattern, text):",
  "            return response if isinstance(response, str)",
  "                else ' '.join(response)",
  '    return "Interesting! Try asking about AI, ML, or Deep Learning."',
  "",
  "# Demo conversation",
  "queries = [",
  '    "Hello there!",',
  '    "What is machine learning?",',
  '    "Tell me about deep learning",',
  "]",
  "for q in queries:",
  '    print(f"User: {q}")',
  '    print(f"Bot : {chatbot_response(q)}")',
  "    print()",
].join("\n");

const OUTPUT_CHATBOT = [
  "Initializing chatbot engine...",
  "Loaded 5 intent patterns",
  "",
  "─── Conversation ──────────────────────────",
  "",
  "User: Hello there!",
  "Bot : Hello! I'm your AI tutor. Ask me about AI or ML!",
  "",
  "User: What is machine learning?",
  "Bot : ML is a subset of AI where systems learn patterns from data",
  "      without being explicitly programmed.",
  "",
  "User: Tell me about deep learning",
  "Bot : Deep Learning uses multi-layer neural networks to learn complex",
  "      representations from raw data like images or text.",
  "",
  "─── End of demo ───────────────────────────",
  "",
  "✓ Chatbot demo complete! Try more queries.",
].join("\n");

const CODE_CATS_DOGS = [
  "# CNN Image Classifier: Cats vs Dogs",
  "import numpy as np",
  "from sklearn.svm import SVC",
  "from sklearn.preprocessing import StandardScaler",
  "from sklearn.pipeline import Pipeline",
  "from sklearn.model_selection import cross_val_score",
  "",
  "def simulate_cnn_features(img_array: np.ndarray) -> np.ndarray:",
  '    """Simulates feature extraction from a CNN layer."""',
  "    # Edge detection proxy",
  "    h_edges = np.mean(np.abs(np.diff(img_array, axis=0)))",
  "    v_edges = np.mean(np.abs(np.diff(img_array, axis=1)))",
  "    # Texture and color stats",
  "    texture = np.std(img_array)",
  "    brightness = np.mean(img_array)",
  "    contrast = np.percentile(img_array, 75) - np.percentile(img_array, 25)",
  "    # Histogram features (8 bins)",
  "    hist = np.histogram(img_array.flatten(), bins=8, range=(0,1))[0] / img_array.size",
  "    return np.array([h_edges, v_edges, texture, brightness, contrast, *hist])",
  "",
  "np.random.seed(42)",
  "# Simulate cat images (slightly smoother, lighter)",
  "cats = [simulate_cnn_features(np.random.beta(3,2,(64,64))) for _ in range(200)]",
  "# Simulate dog images (slightly rougher, more varied)",
  "dogs = [simulate_cnn_features(np.random.beta(2,2,(64,64))*1.1) for _ in range(200)]",
  "",
  "X = np.array(cats + dogs)",
  'y = np.array(["cat"]*200 + ["dog"]*200)',
  "",
  "# RBF SVM with feature scaling",
  "clf = Pipeline([",
  "    ('scaler', StandardScaler()),",
  "    ('svm', SVC(kernel='rbf', C=1.5, gamma='scale', probability=True))",
  "])",
  "",
  "# Cross-validate",
  "scores = cross_val_score(clf, X, y, cv=5, scoring='accuracy')",
  'print(f"CV Accuracy: {scores.mean():.2%} ± {scores.std():.2%}")',
  "clf.fit(X, y)",
  'print("Model ready for inference!")',
].join("\n");

const OUTPUT_CATS_DOGS = [
  "Loading image dataset (simulated)...",
  "  Cats: 200 images  |  Dogs: 200 images",
  "  Feature dims: 13 per image",
  "",
  "Extracting CNN-like features...",
  "  ████████████████ 100% complete",
  "",
  "Training SVM classifier (RBF kernel)...",
  "  C = 1.5  |  gamma = scale",
  "",
  "Cross-Validation Results (5-fold):",
  "  Fold 1: 86.25%",
  "  Fold 2: 87.50%",
  "  Fold 3: 85.00%",
  "  Fold 4: 88.75%",
  "  Fold 5: 86.25%",
  "  ─────────────────",
  "  Mean  : 86.75% ± 1.27%",
  "",
  "Final Model Performance:",
  "  Train Accuracy: 91.5%",
  "  Test Accuracy : 86.8%",
  "",
  "✓ Cats vs Dogs classifier ready!",
].join("\n");

const CODE_CLEAN_DATA = [
  "# Dataset Cleaning & Preprocessing Pipeline",
  "import pandas as pd",
  "import numpy as np",
  "from sklearn.preprocessing import MinMaxScaler",
  "",
  "# Load raw messy dataset",
  "raw_data = {",
  '    "Name"  : ["Alice", "Bob", None, "Diana", "Bob", "Eva"],',
  '    "Age"   : [25, None, 30, 28, 22, 999],',
  '    "Score" : [95, 87, 72, None, 87, 45],',
  '    "City"  : ["NYC", "LA", "NYC", None, "LA", "NYC"],',
  "}",
  "",
  "df = pd.DataFrame(raw_data)",
  'print(f"Raw shape: {df.shape}")',
  'print(f"Missing values:\\n{df.isnull().sum()}")',
  "",
  "# Step 1: Remove duplicates",
  "df = df.drop_duplicates()",
  'print(f"After dedup: {len(df)} rows")',
  "",
  "# Step 2: Handle outliers (Age > 120 is invalid)",
  'df = df[df["Age"] < 120]',
  "",
  "# Step 3: Fill missing values",
  'df["Age"]  = df["Age"].fillna(df["Age"].median())',
  'df["Score"]= df["Score"].fillna(df["Score"].mean())',
  'df["City"] = df["City"].fillna("Unknown")',
  "df = df.dropna(subset=['Name'])",
  "",
  "# Step 4: Normalize numeric columns",
  "scaler = MinMaxScaler()",
  'df[["Age_norm", "Score_norm"]] = scaler.fit_transform(df[["Age", "Score"]])',
  "",
  'print("\\nCleaned dataset:")',
  "print(df.to_string(index=False))",
  'print(f"\\nFinal shape: {df.shape}")',
].join("\n");

const OUTPUT_CLEAN_DATA = [
  "Loading dataset...",
  "Raw shape: (6, 4)",
  "",
  "Missing values:",
  "  Name    1",
  "  Age     1",
  "  Score   1",
  "  City    1",
  "",
  "Step 1 — Removing duplicates...",
  "  After dedup: 5 rows (removed 1 duplicate)",
  "",
  "Step 2 — Removing outliers...",
  "  Removed 1 row (Age=999, invalid)",
  "",
  "Step 3 — Filling missing values...",
  "  Age  → filled with median (26.5)",
  "  Score→ filled with mean  (74.8)",
  "  City → filled with 'Unknown'",
  "  Name → dropped (1 row removed)",
  "",
  "Step 4 — Normalizing features...",
  "  Age_norm  ∈ [0.000, 1.000]",
  "  Score_norm∈ [0.000, 1.000]",
  "",
  "Cleaned dataset:",
  "  Name   Age  Score  City  Age_norm  Score_norm",
  "  Alice  25   95.0   NYC   0.833     1.000",
  "  Diana  28   74.8   None  1.000     0.124",
  "  Eva    26   45.0   NYC   0.917     0.000",
  "",
  "Final shape: (3, 6)",
  "✓ Dataset cleaned and normalized!",
].join("\n");

// ─── Data constants ───────────────────────────────────────────────────────────

const DIFF_COLOR: Record<string, string> = {
  Easy: "#10b981",
  Medium: "#f59e0b",
  Hard: "#ef4444",
};

const CHALLENGES = [
  {
    id: 1,
    title: "Predict House Prices",
    difficulty: "Easy" as const,
    desc: "Build a linear regression model to predict housing costs based on features like size and location.",
    tags: ["Regression", "Scikit-learn"],
    code: CODE_HOUSE_PRICES,
    output: OUTPUT_HOUSE_PRICES,
    hint: "Linear Regression fits a hyperplane to minimize the sum of squared differences. Use train_test_split to evaluate generalization.",
  },
  {
    id: 2,
    title: "Build a Spam Detector",
    difficulty: "Medium" as const,
    desc: "Create a text classifier to distinguish spam emails from legitimate ones using NLP techniques.",
    tags: ["Classification", "NLP"],
    code: CODE_SPAM_DETECTOR,
    output: OUTPUT_SPAM_DETECTOR,
    hint: "CountVectorizer converts text to token counts. Naive Bayes assumes feature independence — works well for text classification.",
  },
  {
    id: 3,
    title: "Train a Chatbot",
    difficulty: "Medium" as const,
    desc: "Develop a simple rule-based chatbot and explore ML approaches to natural language understanding.",
    tags: ["NLP", "Regex"],
    code: CODE_CHATBOT,
    output: OUTPUT_CHATBOT,
    hint: "Pattern matching with regex is a fast baseline. For production, use intent classification with an embeddings model.",
  },
  {
    id: 4,
    title: "Identify Cats vs Dogs",
    difficulty: "Hard" as const,
    desc: "Use a Convolutional Neural Network-inspired approach to classify images as cats or dogs.",
    tags: ["CNN", "Computer Vision"],
    code: CODE_CATS_DOGS,
    output: OUTPUT_CATS_DOGS,
    hint: "CNNs learn hierarchical features — edges → textures → shapes. Here we simulate CNN feature extraction using statistical proxies.",
  },
  {
    id: 5,
    title: "Sort & Clean a Dataset",
    difficulty: "Easy" as const,
    desc: "Learn essential data preprocessing: handling missing values, outliers, and feature normalization.",
    tags: ["Pandas", "Preprocessing"],
    code: CODE_CLEAN_DATA,
    output: OUTPUT_CLEAN_DATA,
    hint: "Data cleaning is ~80% of ML work. Always check for duplicates, outliers, and missing values before modeling.",
  },
];

const LIBRARIES = [
  {
    name: "NumPy",
    emoji: "🔢",
    color: "#4C78C8",
    desc: "Numerical computing for N-dimensional arrays and matrix operations",
    doc: "https://numpy.org/doc/",
  },
  {
    name: "Pandas",
    emoji: "🐼",
    color: "#130654",
    desc: "Data manipulation and analysis with DataFrames",
    doc: "https://pandas.pydata.org/docs/",
  },
  {
    name: "Matplotlib",
    emoji: "📊",
    color: "#11557C",
    desc: "Data visualization — static, animated, and interactive plots",
    doc: "https://matplotlib.org/stable/",
  },
  {
    name: "Scikit-learn",
    emoji: "🤖",
    color: "#F7931E",
    desc: "Comprehensive ML algorithms, pipelines, and evaluation tools",
    doc: "https://scikit-learn.org/stable/",
  },
];

const PIPELINE_STAGES = [
  {
    label: "Dataset",
    icon: Database,
    color: "#3b82f6",
    bg: "rgba(59,130,246,0.12)",
    border: "rgba(59,130,246,0.35)",
    desc: "Load and split your raw data into training and test sets",
  },
  {
    label: "Algorithm",
    icon: Cpu,
    color: "#7C3AED",
    bg: "rgba(124,58,237,0.12)",
    border: "rgba(124,58,237,0.35)",
    desc: "Choose an ML model suited to your problem type",
  },
  {
    label: "Training",
    icon: Activity,
    color: "#f59e0b",
    bg: "rgba(245,158,11,0.12)",
    border: "rgba(245,158,11,0.35)",
    desc: "Fit the model to training data and tune hyperparameters",
  },
  {
    label: "Prediction",
    icon: Target,
    color: "#10b981",
    bg: "rgba(16,185,129,0.12)",
    border: "rgba(16,185,129,0.35)",
    desc: "Evaluate on test set and deploy for real-world inference",
  },
];

// ─── Component ────────────────────────────────────────────────────────────────

export default function Practice() {
  const [difficulty, setDifficulty] = useState<Difficulty>("All");
  const [selectedChallenge, setSelectedChallenge] = useState(CHALLENGES[0]);
  const [editorCode, setEditorCode] = useState(CHALLENGES[0].code);
  const [output, setOutput] = useState("");
  const [running, setRunning] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [activePipelineStep, setActivePipelineStep] = useState(-1);
  const [pipelineBuilt, setPipelineBuilt] = useState(false);
  const editorRef = useRef<HTMLTextAreaElement>(null);

  const filtered =
    difficulty === "All"
      ? CHALLENGES
      : CHALLENGES.filter((c) => c.difficulty === difficulty);

  const selectChallenge = (c: (typeof CHALLENGES)[number]) => {
    setSelectedChallenge(c);
    setEditorCode(c.code);
    setOutput("");
    setShowHint(false);
  };

  const runCode = () => {
    setRunning(true);
    setOutput("");
    setTimeout(() => {
      setOutput(selectedChallenge.output);
      setRunning(false);
    }, 1200);
  };

  const resetCode = () => {
    setEditorCode(selectedChallenge.code);
    setOutput("");
    setShowHint(false);
  };

  const buildPipeline = () => {
    // Animate through stages
    setActivePipelineStep(0);
    setPipelineBuilt(false);
    let step = 0;
    const interval = setInterval(() => {
      step++;
      setActivePipelineStep(step);
      if (step >= PIPELINE_STAGES.length - 1) {
        clearInterval(interval);
        setTimeout(() => setPipelineBuilt(true), 300);
      }
    }, 400);
  };

  return (
    <div className="relative min-h-screen" style={{ zIndex: 1 }}>
      <ParticleBackground />

      {/* ── Page Header ── */}
      <div
        className="relative py-14"
        style={{
          background:
            "linear-gradient(180deg, rgba(34,211,238,0.04) 0%, transparent 100%)",
          borderBottom: "1px solid rgba(34,211,238,0.1)",
          zIndex: 2,
        }}
        data-ocid="practice.header.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-accent uppercase tracking-widest mb-5"
              style={{
                background: "rgba(34,211,238,0.08)",
                border: "1px solid rgba(34,211,238,0.25)",
                color: "#22D3EE",
              }}
            >
              <Code2 className="w-3 h-3" />
              Coding Playground
            </div>
            <h1 className="text-4xl sm:text-5xl font-display font-bold text-white mb-4 leading-tight">
              Practice <span className="text-gradient-cyan">ML Algorithms</span>
              <br className="hidden sm:block" /> with Real Code
            </h1>
            <p
              className="max-w-xl mx-auto text-base sm:text-lg"
              style={{ color: "rgba(255,255,255,0.5)" }}
            >
              Select a challenge, read pre-written Python code, run it live, and
              understand the output.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="relative py-10" style={{ zIndex: 2 }}>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          {/* ── Difficulty Filter + Challenge Cards ── */}
          <section data-ocid="practice.challenges.section">
            {/* Filter pills */}
            <div
              className="flex items-center gap-2 mb-6 flex-wrap"
              data-ocid="practice.difficulty.tab"
            >
              <span
                className="text-xs font-accent uppercase tracking-wider mr-1"
                style={{ color: "rgba(255,255,255,0.35)" }}
              >
                Filter:
              </span>
              {(["All", "Easy", "Medium", "Hard"] as Difficulty[]).map((d) => {
                const isActive = difficulty === d;
                const col =
                  d === "All"
                    ? "#a78bfa"
                    : DIFF_COLOR[d as keyof typeof DIFF_COLOR];
                return (
                  <button
                    type="button"
                    key={d}
                    onClick={() => setDifficulty(d)}
                    className="px-4 py-1.5 rounded-full text-sm font-medium transition-smooth"
                    style={{
                      background: isActive
                        ? `${col}20`
                        : "rgba(255,255,255,0.04)",
                      border: `1px solid ${isActive ? `${col}60` : "rgba(255,255,255,0.1)"}`,
                      color: isActive ? col : "rgba(255,255,255,0.45)",
                      boxShadow: isActive ? `0 0 12px ${col}30` : "none",
                    }}
                    data-ocid={`practice.difficulty.${d.toLowerCase()}.tab`}
                  >
                    {d}
                  </button>
                );
              })}
            </div>

            {/* Challenge cards */}
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
              <AnimatePresence>
                {filtered.map((c, i) => {
                  const isSelected = selectedChallenge.id === c.id;
                  return (
                    <motion.div
                      key={c.id}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.25, delay: i * 0.04 }}
                      data-ocid={`practice.challenges.item.${i + 1}`}
                    >
                      <button
                        type="button"
                        onClick={() => selectChallenge(c)}
                        className="glass text-left p-4 rounded-xl w-full h-full flex flex-col transition-smooth group"
                        style={{
                          border: isSelected
                            ? "1px solid rgba(34,211,238,0.5)"
                            : "1px solid rgba(255,255,255,0.07)",
                          boxShadow: isSelected
                            ? "0 0 24px rgba(34,211,238,0.18), inset 0 1px 0 rgba(34,211,238,0.1)"
                            : "none",
                          background: isSelected
                            ? "rgba(34,211,238,0.05)"
                            : "rgba(255,255,255,0.03)",
                        }}
                      >
                        {/* Difficulty badge */}
                        <span
                          className="self-start text-xs font-accent font-semibold px-2.5 py-0.5 rounded-full mb-3"
                          style={{
                            background: `${DIFF_COLOR[c.difficulty]}18`,
                            color: DIFF_COLOR[c.difficulty],
                            border: `1px solid ${DIFF_COLOR[c.difficulty]}35`,
                          }}
                        >
                          {c.difficulty}
                        </span>
                        <div className="font-display font-semibold text-sm text-white mb-1.5 leading-snug group-hover:text-gradient-cyan transition-smooth">
                          {c.title}
                        </div>
                        <p
                          className="text-xs leading-relaxed flex-1"
                          style={{ color: "rgba(255,255,255,0.42)" }}
                        >
                          {c.desc}
                        </p>
                        {/* Tags */}
                        <div className="flex flex-wrap gap-1 mt-3">
                          {c.tags.map((t) => (
                            <span
                              key={t}
                              className="text-xs px-1.5 py-0.5 rounded"
                              style={{
                                background: "rgba(255,255,255,0.05)",
                                color: "rgba(255,255,255,0.35)",
                              }}
                            >
                              {t}
                            </span>
                          ))}
                        </div>
                        {/* Start button */}
                        <div
                          className="mt-3 flex items-center gap-1 text-xs font-medium transition-smooth"
                          style={{
                            color: isSelected
                              ? "#22D3EE"
                              : "rgba(255,255,255,0.35)",
                          }}
                        >
                          {isSelected ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              Selected
                            </>
                          ) : (
                            <>
                              Start Challenge
                              <ChevronRight className="w-3.5 h-3.5" />
                            </>
                          )}
                        </div>
                      </button>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </section>

          {/* ── Code Editor + Output Panel ── */}
          <motion.section
            key={selectedChallenge.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="grid lg:grid-cols-2 gap-0 rounded-2xl overflow-hidden"
            style={{
              border: "1px solid rgba(124,58,237,0.25)",
              boxShadow: "0 0 40px rgba(124,58,237,0.12)",
            }}
            data-ocid="practice.editor.panel"
          >
            {/* Left: Code Editor */}
            <div
              className="flex flex-col"
              style={{
                background: "rgba(8,10,30,0.85)",
                borderRight: "1px solid rgba(124,58,237,0.2)",
                minHeight: 480,
              }}
            >
              {/* Editor header */}
              <div
                className="flex items-center justify-between px-4 py-3"
                style={{
                  background: "rgba(124,58,237,0.1)",
                  borderBottom: "1px solid rgba(124,58,237,0.2)",
                }}
              >
                <div className="flex items-center gap-3">
                  {/* macOS traffic lights */}
                  <div className="flex gap-1.5">
                    {["#ef4444", "#f59e0b", "#10b981"].map((c) => (
                      <div
                        key={c}
                        className="w-3 h-3 rounded-full"
                        style={{ background: c }}
                      />
                    ))}
                  </div>
                  <span
                    className="font-mono text-xs"
                    style={{ color: "rgba(255,255,255,0.35)" }}
                  >
                    {selectedChallenge.title
                      .toLowerCase()
                      .replace(/[^a-z0-9]/g, "_")}
                    .py
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className="font-accent text-xs px-2 py-0.5 rounded"
                    style={{
                      background: "rgba(124,58,237,0.2)",
                      color: "#a78bfa",
                      border: "1px solid rgba(124,58,237,0.3)",
                    }}
                  >
                    Python
                  </span>
                  <button
                    type="button"
                    onClick={() => setShowHint(!showHint)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-smooth"
                    style={{
                      background: showHint
                        ? "rgba(245,158,11,0.15)"
                        : "rgba(245,158,11,0.06)",
                      border: "1px solid rgba(245,158,11,0.3)",
                      color: "#f59e0b",
                    }}
                    data-ocid="practice.editor.hint.button"
                  >
                    <Lightbulb className="w-3.5 h-3.5" />
                    Hint
                  </button>
                </div>
              </div>

              {/* Hint bar */}
              <AnimatePresence>
                {showHint && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className="overflow-hidden"
                  >
                    <div
                      className="px-5 py-3 text-xs flex gap-2"
                      style={{
                        background: "rgba(245,158,11,0.07)",
                        borderBottom: "1px solid rgba(245,158,11,0.18)",
                        color: "rgba(245,158,11,0.85)",
                      }}
                    >
                      <Lightbulb
                        className="w-3.5 h-3.5 mt-0.5 shrink-0"
                        style={{ color: "#f59e0b" }}
                      />
                      <span>
                        <strong>Hint:</strong> {selectedChallenge.hint}
                      </span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Line numbers + textarea */}
              <div className="flex flex-1 overflow-hidden">
                {/* Line numbers */}
                <div
                  className="select-none pt-4 px-3 text-right font-mono text-xs leading-6"
                  style={{
                    color: "rgba(124,58,237,0.45)",
                    background: "rgba(0,0,0,0.2)",
                    borderRight: "1px solid rgba(124,58,237,0.1)",
                    minWidth: 44,
                    userSelect: "none",
                  }}
                >
                  {editorCode.split("\n").map((_, idx) => (
                    // biome-ignore lint/suspicious/noArrayIndexKey: line numbers require index
                    <div key={idx}>{idx + 1}</div>
                  ))}
                </div>
                {/* Code textarea */}
                <textarea
                  ref={editorRef}
                  value={editorCode}
                  onChange={(e) => setEditorCode(e.target.value)}
                  spellCheck={false}
                  className="flex-1 p-4 font-mono text-xs leading-6 resize-none focus:outline-none"
                  style={{
                    background: "transparent",
                    color: "rgba(255,255,255,0.88)",
                    caretColor: "#22D3EE",
                    tabSize: 4,
                    minHeight: 320,
                  }}
                  data-ocid="practice.editor.textarea"
                />
              </div>

              {/* Editor controls */}
              <div
                className="flex items-center gap-3 px-4 py-3"
                style={{ borderTop: "1px solid rgba(124,58,237,0.15)" }}
              >
                <button
                  type="button"
                  onClick={runCode}
                  disabled={running}
                  className="neon-btn-primary flex items-center gap-2 px-5 py-2 text-sm"
                  data-ocid="practice.editor.run.primary_button"
                >
                  {running ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" />
                      Run Code
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={resetCode}
                  className="neon-btn-cyan flex items-center gap-2 px-4 py-2 text-sm"
                  data-ocid="practice.editor.reset.button"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Reset
                </button>
              </div>
            </div>

            {/* Right: Output Panel */}
            <div
              className="flex flex-col"
              style={{
                background: "rgba(5,8,22,0.9)",
                minHeight: 480,
              }}
            >
              {/* Output header */}
              <div
                className="flex items-center justify-between px-4 py-3"
                style={{
                  background: "rgba(34,211,238,0.06)",
                  borderBottom: "1px solid rgba(34,211,238,0.15)",
                }}
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-2 h-2 rounded-full"
                    style={{
                      background: running
                        ? "#f59e0b"
                        : output
                          ? "#10b981"
                          : "rgba(255,255,255,0.2)",
                      boxShadow: running
                        ? "0 0 8px #f59e0b"
                        : output
                          ? "0 0 8px #10b981"
                          : "none",
                      transition: "all 0.3s",
                    }}
                  />
                  <span
                    className="font-mono text-xs"
                    style={{ color: "rgba(255,255,255,0.4)" }}
                  >
                    Output Console
                  </span>
                </div>
                <span
                  className="font-accent text-xs px-2 py-0.5 rounded"
                  style={{
                    background: running
                      ? "rgba(245,158,11,0.12)"
                      : output
                        ? "rgba(16,185,129,0.12)"
                        : "rgba(255,255,255,0.05)",
                    color: running
                      ? "#f59e0b"
                      : output
                        ? "#10b981"
                        : "rgba(255,255,255,0.3)",
                    border: `1px solid ${running ? "rgba(245,158,11,0.25)" : output ? "rgba(16,185,129,0.25)" : "rgba(255,255,255,0.1)"}`,
                  }}
                >
                  {running ? "Running" : output ? "Complete" : "Idle"}
                </span>
              </div>

              {/* Output content */}
              <div
                className="flex-1 p-5 overflow-auto"
                data-ocid="practice.output.panel"
              >
                {running && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex items-center gap-2 text-xs"
                    style={{ color: "#22D3EE" }}
                    data-ocid="practice.output.loading_state"
                  >
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Executing Python code...
                  </motion.div>
                )}

                {output && !running && (
                  <motion.pre
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="font-mono text-xs leading-6"
                    style={{ color: "#4ade80", whiteSpace: "pre-wrap" }}
                    data-ocid="practice.output.success_state"
                  >
                    {output}
                  </motion.pre>
                )}

                {!output && !running && (
                  <div
                    className="h-full flex flex-col items-center justify-center gap-4 opacity-30"
                    data-ocid="practice.output.empty_state"
                  >
                    <div
                      className="w-14 h-14 rounded-2xl flex items-center justify-center"
                      style={{
                        background: "rgba(34,211,238,0.08)",
                        border: "1px solid rgba(34,211,238,0.15)",
                      }}
                    >
                      <Code2 className="w-7 h-7" style={{ color: "#22D3EE" }} />
                    </div>
                    <div className="text-center">
                      <p
                        className="text-sm font-medium"
                        style={{ color: "rgba(255,255,255,0.6)" }}
                      >
                        No output yet
                      </p>
                      <p
                        className="text-xs mt-1"
                        style={{ color: "rgba(255,255,255,0.3)" }}
                      >
                        Press Run Code to execute
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.section>

          {/* ── ML Pipeline Builder ── */}
          <section data-ocid="practice.pipeline.section">
            <div className="mb-6">
              <h2 className="text-2xl font-display font-bold text-white mb-1">
                ML Pipeline Builder
              </h2>
              <p
                className="text-sm"
                style={{ color: "rgba(255,255,255,0.45)" }}
              >
                Click each stage to progress through your machine learning
                workflow
              </p>
            </div>

            <div
              className="glass rounded-2xl p-6"
              style={{ border: "1px solid rgba(124,58,237,0.22)" }}
            >
              {/* Stage boxes */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-6 overflow-x-auto pb-2">
                {PIPELINE_STAGES.map((stage, i) => {
                  const StageIcon = stage.icon;
                  const isActive = activePipelineStep >= i;
                  const isCurrent = activePipelineStep === i;
                  return (
                    <div key={stage.label} className="flex items-center gap-3">
                      <motion.button
                        type="button"
                        onClick={() => setActivePipelineStep(i)}
                        animate={
                          isCurrent
                            ? {
                                scale: [1, 1.04, 1],
                                transition: { duration: 0.4 },
                              }
                            : { scale: 1 }
                        }
                        className="flex flex-col items-center gap-2 px-5 py-4 rounded-xl transition-smooth flex-1 sm:flex-none sm:min-w-[130px]"
                        style={{
                          background: isActive
                            ? stage.bg
                            : "rgba(255,255,255,0.03)",
                          border: `1px solid ${isActive ? stage.border : "rgba(255,255,255,0.08)"}`,
                          boxShadow: isCurrent
                            ? `0 0 20px ${stage.color}35`
                            : "none",
                        }}
                        data-ocid={`practice.pipeline.step.${i + 1}`}
                      >
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center"
                          style={{
                            background: isActive
                              ? `${stage.color}20`
                              : "rgba(255,255,255,0.05)",
                            border: `1px solid ${isActive ? `${stage.color}40` : "rgba(255,255,255,0.08)"}`,
                          }}
                        >
                          <StageIcon
                            className="w-5 h-5"
                            style={{
                              color: isActive
                                ? stage.color
                                : "rgba(255,255,255,0.3)",
                            }}
                          />
                        </div>
                        <span
                          className="font-display font-semibold text-sm"
                          style={{
                            color: isActive ? "#fff" : "rgba(255,255,255,0.3)",
                          }}
                        >
                          {stage.label}
                        </span>
                        {isActive && (
                          <span
                            className="text-xs"
                            style={{ color: stage.color, opacity: 0.8 }}
                          >
                            ✓ Active
                          </span>
                        )}
                      </motion.button>
                      {i < PIPELINE_STAGES.length - 1 && (
                        <ArrowRight
                          className="w-5 h-5 shrink-0 hidden sm:block"
                          style={{
                            color:
                              activePipelineStep > i
                                ? stage.color
                                : "rgba(255,255,255,0.12)",
                            transition: "color 0.3s",
                          }}
                        />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Stage description */}
              <AnimatePresence mode="wait">
                {activePipelineStep >= 0 && (
                  <motion.div
                    key={activePipelineStep}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.2 }}
                    className="rounded-xl px-4 py-3 mb-5 text-sm"
                    style={{
                      background: "rgba(124,58,237,0.08)",
                      border: "1px solid rgba(124,58,237,0.2)",
                      color: "rgba(255,255,255,0.65)",
                    }}
                  >
                    <strong className="text-white">
                      {PIPELINE_STAGES[activePipelineStep]?.label}:
                    </strong>{" "}
                    {PIPELINE_STAGES[activePipelineStep]?.desc}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Build button + success */}
              <div className="flex items-center gap-4 flex-wrap">
                <button
                  type="button"
                  onClick={buildPipeline}
                  className="neon-btn-primary flex items-center gap-2 px-6 py-2.5 text-sm"
                  data-ocid="practice.pipeline.build.primary_button"
                >
                  <Zap className="w-4 h-4" />
                  Build Pipeline
                </button>
                <AnimatePresence>
                  {pipelineBuilt && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      className="flex items-center gap-2 text-sm font-medium"
                      style={{ color: "#10b981" }}
                      data-ocid="practice.pipeline.success_state"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Pipeline built successfully!
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </section>

          {/* ── Library Reference Cards ── */}
          <section data-ocid="practice.libraries.section">
            <div className="mb-5">
              <h2 className="text-2xl font-display font-bold text-white mb-1">
                Library Reference
              </h2>
              <p
                className="text-sm"
                style={{ color: "rgba(255,255,255,0.45)" }}
              >
                Core Python libraries used in these challenges
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {LIBRARIES.map((lib, i) => (
                <motion.div
                  key={lib.name}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: i * 0.08 }}
                  className="glass glass-hover rounded-xl p-5 flex flex-col gap-3"
                  data-ocid={`practice.libraries.item.${i + 1}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{lib.emoji}</span>
                    <div className="font-display font-bold text-sm text-white">
                      {lib.name}
                    </div>
                  </div>
                  <p
                    className="text-xs leading-relaxed flex-1"
                    style={{ color: "rgba(255,255,255,0.42)" }}
                  >
                    {lib.desc}
                  </p>
                  <a
                    href={lib.doc}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-medium transition-smooth"
                    style={{ color: "#22D3EE" }}
                    data-ocid={`practice.libraries.docs.${i + 1}.link`}
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    View Docs
                    <ExternalLink className="w-3 h-3 opacity-60" />
                  </a>
                </motion.div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
