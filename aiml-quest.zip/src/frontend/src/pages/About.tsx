import { Link } from "@tanstack/react-router";
import { Brain, Code2, TrendingUp, Zap } from "lucide-react";
import { motion } from "motion/react";
import ParticleBackground from "../components/ParticleBackground";

const MISSION_CARDS = [
  {
    icon: Brain,
    title: "Make AI Accessible",
    desc: "Breaking down complex AI/ML concepts into digestible, interactive lessons anyone can understand.",
    color: "#7C3AED",
    glow: "rgba(124,58,237,0.25)",
  },
  {
    icon: Code2,
    title: "Learn by Doing",
    desc: "Hands-on coding challenges, simulations, and games that reinforce theoretical concepts.",
    color: "#22D3EE",
    glow: "rgba(34,211,238,0.2)",
  },
  {
    icon: TrendingUp,
    title: "Track Your Journey",
    desc: "Gamified progress system with XP, badges, and streaks to keep you motivated.",
    color: "#10b981",
    glow: "rgba(16,185,129,0.2)",
  },
];

const TEAM = [
  {
    initials: "AC",
    name: "Aria Chen",
    role: "AI Research Lead",
    color: "#7C3AED",
  },
  {
    initials: "MW",
    name: "Marcus Wei",
    role: "Platform Engineer",
    color: "#22D3EE",
  },
  {
    initials: "PN",
    name: "Priya Nair",
    role: "Curriculum Designer",
    color: "#10b981",
  },
];

const TIMELINE = [
  {
    quarter: "Q1 2025",
    milestone: "Core learning platform launch",
    done: true,
  },
  {
    quarter: "Q2 2025",
    milestone: "Mini Games and simulations",
    done: true,
  },
  {
    quarter: "Q3 2025",
    milestone: "Quiz Arena and leaderboards",
    done: false,
  },
  {
    quarter: "Q4 2025",
    milestone: "AI-powered personalized learning paths",
    done: false,
  },
];

export default function About() {
  return (
    <div className="relative min-h-screen" style={{ zIndex: 1 }}>
      <ParticleBackground />

      {/* ── Hero ── */}
      <section
        className="relative py-24"
        style={{
          background: "rgba(124,58,237,0.04)",
          borderBottom: "1px solid rgba(124,58,237,0.12)",
          zIndex: 2,
        }}
        data-ocid="about.hero.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65 }}
            className="max-w-3xl mx-auto"
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-accent uppercase tracking-widest mb-6"
              style={{
                background: "rgba(124,58,237,0.1)",
                border: "1px solid rgba(124,58,237,0.3)",
                color: "#a78bfa",
              }}
            >
              About AIML Quest
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold text-white mb-6 leading-tight">
              About <span className="text-gradient-hero">AIML Quest</span>
            </h1>

            <p
              className="text-lg leading-relaxed max-w-2xl mx-auto"
              style={{ color: "rgba(255,255,255,0.6)" }}
            >
              We believe AI and Machine Learning should be accessible to
              everyone. AIML Quest combines gamified learning, interactive
              simulations, and real-world coding practice to make complex
              concepts approachable and engaging.
            </p>
          </motion.div>
        </div>
      </section>

      {/* ── Mission Cards ── */}
      <section
        className="relative py-20"
        style={{ zIndex: 2 }}
        data-ocid="about.mission.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              Our <span className="text-gradient-purple">Mission</span>
            </h2>
            <p
              className="max-w-xl mx-auto text-base"
              style={{ color: "rgba(255,255,255,0.5)" }}
            >
              Making world-class AI and ML education accessible, engaging, and
              effective for everyone.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {MISSION_CARDS.map(
              ({ icon: Icon, title, desc, color, glow }, i) => (
                <motion.div
                  key={title}
                  initial={{ opacity: 0, y: 32 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.12 }}
                  className="glass glass-hover rounded-2xl p-7 flex flex-col gap-4"
                  style={{
                    border: `1px solid ${color}25`,
                  }}
                  data-ocid={`about.mission.item.${i + 1}`}
                >
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{
                      background: `${color}15`,
                      border: `1px solid ${color}35`,
                      boxShadow: `0 0 20px ${glow}`,
                    }}
                  >
                    <Icon className="w-7 h-7" style={{ color }} />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-white text-lg mb-2">
                      {title}
                    </h3>
                    <p
                      className="text-sm leading-relaxed"
                      style={{ color: "rgba(255,255,255,0.55)" }}
                    >
                      {desc}
                    </p>
                  </div>
                </motion.div>
              ),
            )}
          </div>
        </div>
      </section>

      {/* ── Team ── */}
      <section
        className="relative py-20"
        style={{ zIndex: 2, background: "rgba(124,58,237,0.025)" }}
        data-ocid="about.team.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              Built by Learners,{" "}
              <span className="text-gradient-cyan">for Learners</span>
            </h2>
            <p
              className="max-w-xl mx-auto text-base"
              style={{ color: "rgba(255,255,255,0.5)" }}
            >
              A passionate team dedicated to transforming how the world learns
              about artificial intelligence.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-3 gap-6 max-w-3xl mx-auto">
            {TEAM.map(({ initials, name, role, color }, i) => (
              <motion.div
                key={name}
                initial={{ opacity: 0, scale: 0.88 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.42, delay: i * 0.1 }}
                className="glass glass-hover rounded-2xl p-7 flex flex-col items-center text-center gap-4"
                data-ocid={`about.team.item.${i + 1}`}
              >
                {/* Avatar placeholder circle */}
                <div
                  className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-accent font-bold text-white flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${color}40, ${color}15)`,
                    border: `2px solid ${color}40`,
                    boxShadow: `0 0 24px ${color}25`,
                    color,
                  }}
                >
                  {initials}
                </div>
                <div>
                  <div className="font-display font-bold text-white text-base mb-1">
                    {name}
                  </div>
                  <div
                    className="text-sm"
                    style={{ color: "rgba(255,255,255,0.5)" }}
                  >
                    {role}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Roadmap / Timeline ── */}
      <section
        className="relative py-20"
        style={{ zIndex: 2 }}
        data-ocid="about.roadmap.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              Our <span className="text-gradient-hero">Roadmap</span>
            </h2>
            <p
              className="max-w-xl mx-auto text-base"
              style={{ color: "rgba(255,255,255,0.5)" }}
            >
              Milestones on our journey to redefine AI education.
            </p>
          </motion.div>

          <div className="relative max-w-2xl mx-auto">
            {/* Vertical line */}
            <div
              className="absolute left-6 top-0 bottom-0 w-px"
              style={{
                background:
                  "linear-gradient(to bottom, #7C3AED, #22D3EE, rgba(34,211,238,0.1))",
              }}
            />

            <div className="flex flex-col gap-8">
              {TIMELINE.map(({ quarter, milestone, done }, i) => (
                <motion.div
                  key={quarter}
                  initial={{ opacity: 0, x: -24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.45, delay: i * 0.12 }}
                  className="relative flex items-start gap-6 pl-16"
                  data-ocid={`about.roadmap.item.${i + 1}`}
                >
                  {/* Dot */}
                  <div
                    className="absolute left-4 top-1 w-4 h-4 rounded-full flex-shrink-0 -translate-x-1/2"
                    style={{
                      background: done ? "#7C3AED" : "rgba(124,58,237,0.25)",
                      border: done
                        ? "2px solid #a78bfa"
                        : "2px solid rgba(124,58,237,0.4)",
                      boxShadow: done
                        ? "0 0 12px rgba(124,58,237,0.6)"
                        : "none",
                    }}
                  />

                  <div
                    className="glass rounded-xl p-5 flex-1"
                    style={{
                      border: done
                        ? "1px solid rgba(124,58,237,0.3)"
                        : "1px solid rgba(255,255,255,0.07)",
                    }}
                  >
                    <div className="flex items-center gap-3 mb-1.5 flex-wrap">
                      <span
                        className="font-accent text-xs font-bold tracking-widest px-2.5 py-1 rounded-full"
                        style={{
                          background: done
                            ? "rgba(124,58,237,0.18)"
                            : "rgba(255,255,255,0.06)",
                          color: done ? "#a78bfa" : "rgba(255,255,255,0.45)",
                          border: done
                            ? "1px solid rgba(124,58,237,0.3)"
                            : "1px solid rgba(255,255,255,0.1)",
                        }}
                      >
                        {quarter}
                      </span>
                      {done && (
                        <span
                          className="text-xs font-medium px-2 py-0.5 rounded-full"
                          style={{
                            background: "rgba(16,185,129,0.12)",
                            border: "1px solid rgba(16,185,129,0.3)",
                            color: "#10b981",
                          }}
                        >
                          ✓ Launched
                        </span>
                      )}
                    </div>
                    <p className="text-sm font-display font-medium text-white">
                      {milestone}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section
        className="relative py-20"
        style={{ zIndex: 2 }}
        data-ocid="about.cta.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="glass rounded-3xl p-12 text-center max-w-2xl mx-auto"
            style={{
              border: "1px solid rgba(124,58,237,0.35)",
              boxShadow:
                "0 0 60px rgba(124,58,237,0.14), 0 0 120px rgba(34,211,238,0.06)",
            }}
          >
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6"
              style={{
                background: "linear-gradient(135deg, #7C3AED, #22D3EE)",
                boxShadow: "0 0 30px rgba(124,58,237,0.5)",
              }}
            >
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl font-display font-bold text-white mb-4">
              Start Learning Today
            </h2>
            <p
              className="mb-8 text-base leading-relaxed"
              style={{ color: "rgba(255,255,255,0.55)" }}
            >
              Begin your AI and Machine Learning journey right now. Interactive
              lessons, real coding challenges, and gamified progress — all in
              one place.
            </p>
            <Link
              to="/learn"
              className="neon-btn-primary inline-flex items-center gap-2 px-8 py-3.5 text-base"
              data-ocid="about.cta.start_learning.primary_button"
            >
              <Zap className="w-5 h-5" />
              Start Learning Free
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
