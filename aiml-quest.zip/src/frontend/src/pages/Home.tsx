import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Brain,
  ChevronRight,
  Code2,
  Cpu,
  Database,
  Gamepad2,
  Network,
  Play,
  Rocket,
  Star,
  Trophy,
  Users,
  Zap,
} from "lucide-react";
import { motion } from "motion/react";

// ─── Data ───────────────────────────────────────────────────────────────────

const FEATURES = [
  {
    icon: BookOpen,
    title: "Interactive Lessons",
    desc: "Step-by-step AI/ML lessons with interactive examples and real-world applications.",
    color: "#7C3AED",
    badge: "Core",
    link: "/learn",
  },
  {
    icon: Code2,
    title: "Coding Playground",
    desc: "Write and run Python code in your browser. Practice ML algorithms hands-on.",
    color: "#22D3EE",
    badge: "Practice",
    link: "/practice",
  },
  {
    icon: Gamepad2,
    title: "Mini Games",
    desc: "Learn through gamified challenges. Earn XP, unlock badges, compete on leaderboards.",
    color: "#a855f7",
    badge: "Fun",
    link: "/games",
  },
  {
    icon: Cpu,
    title: "AI Simulations",
    desc: "See AI in action: self-driving cars, spam detection, face recognition and more.",
    color: "#22D3EE",
    badge: "Simulate",
    link: "/simulations",
  },
  {
    icon: Trophy,
    title: "Quiz Arena",
    desc: "Test your knowledge with timed quizzes, daily challenges, and multiplayer battles.",
    color: "#f59e0b",
    badge: "Compete",
    link: "/quiz",
  },
  {
    icon: BarChart3,
    title: "Progress Tracker",
    desc: "Track your learning journey with detailed analytics and achievement milestones.",
    color: "#10b981",
    badge: "Track",
    link: "/progress",
  },
];

const STATS = [
  { value: "50+", label: "Topics Covered", icon: BookOpen },
  { value: "20+", label: "Mini Games", icon: Gamepad2 },
  { value: "1K+", label: "Learners", icon: Users },
  { value: "4.9★", label: "Rating", icon: Star },
];

const LEARNING_LEVELS = [
  {
    level: "Beginner",
    icon: Rocket,
    color: "#10b981",
    topics: [
      "What is AI?",
      "What is Machine Learning?",
      "Supervised Learning",
      "Unsupervised Learning",
      "Reinforcement Learning",
      "Datasets & Features",
    ],
    badge: "Start Here",
    desc: "Perfect for newcomers to AI and ML — no prior coding experience needed.",
  },
  {
    level: "Intermediate",
    icon: Brain,
    color: "#7C3AED",
    topics: [
      "Linear Regression",
      "Decision Trees",
      "K-Nearest Neighbors",
      "Classification vs Regression",
      "Neural Networks",
    ],
    badge: "Level Up",
    desc: "Dive into algorithms that power modern machine learning applications.",
  },
  {
    level: "Advanced",
    icon: Network,
    color: "#22D3EE",
    topics: [
      "Deep Learning",
      "Convolutional Neural Nets",
      "Natural Language Processing",
      "Computer Vision",
      "Recommendation Systems",
    ],
    badge: "Expert",
    desc: "Master state-of-the-art techniques used at top AI research labs.",
  },
];

// Floating icon chips around the hero brain
const FLOATING_CHIPS = [
  {
    icon: Brain,
    color: "#7C3AED",
    label: "AI",
    x: "-left-10",
    y: "top-8",
    delay: 0,
  },
  {
    icon: Code2,
    color: "#22D3EE",
    label: "Code",
    x: "-right-8",
    y: "top-16",
    delay: 0.8,
  },
  {
    icon: Database,
    color: "#f59e0b",
    label: "Data",
    x: "-left-6",
    y: "bottom-24",
    delay: 1.4,
  },
  {
    icon: Network,
    color: "#a855f7",
    label: "NN",
    x: "-right-4",
    y: "bottom-16",
    delay: 0.4,
  },
  {
    icon: Trophy,
    color: "#10b981",
    label: "XP",
    x: "left-1/4",
    y: "-top-6",
    delay: 1.0,
  },
];

// ─── Component ───────────────────────────────────────────────────────────────

export default function Home() {
  return (
    <div className="relative overflow-x-hidden">
      {/* ══ HERO SECTION ══ */}
      <section
        className="relative min-h-[95vh] flex items-center py-20 grid-pattern"
        style={{ zIndex: 1 }}
        data-ocid="home.hero.section"
      >
        {/* Ambient glows */}
        <div
          className="pointer-events-none absolute -top-20 -left-20 w-[500px] h-[500px] rounded-full opacity-20"
          style={{
            background: "radial-gradient(circle, #7C3AED 0%, transparent 70%)",
          }}
        />
        <div
          className="pointer-events-none absolute top-1/3 -right-20 w-[400px] h-[400px] rounded-full opacity-10"
          style={{
            background: "radial-gradient(circle, #22D3EE 0%, transparent 70%)",
          }}
        />

        <div className="container mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-14 items-center">
            {/* ── Left: Text ── */}
            <div className="space-y-8">
              {/* Tag */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-accent font-medium tracking-wider uppercase"
                style={{
                  background: "rgba(124,58,237,0.12)",
                  border: "1px solid rgba(124,58,237,0.3)",
                  color: "#a78bfa",
                  boxShadow: "0 0 20px rgba(124,58,237,0.15)",
                }}
              >
                <Zap className="w-3 h-3" style={{ color: "#22D3EE" }} />
                The Future of AI Education Is Here
              </motion.div>

              {/* Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.65, delay: 0.1 }}
                className="text-4xl sm:text-5xl lg:text-[3.5rem] font-display font-bold leading-[1.15] tracking-tight"
              >
                <span className="text-white">Learn </span>
                <span
                  style={{
                    background: "linear-gradient(135deg, #a78bfa, #7C3AED)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  Artificial Intelligence
                </span>
                <span className="text-white"> &amp; </span>
                <span
                  style={{
                    background: "linear-gradient(135deg, #22D3EE, #a78bfa)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  Machine Learning
                </span>
                <br />
                <span style={{ color: "rgba(255,255,255,0.88)" }}>
                  Through Games, Coding &amp; Real-World Challenges
                </span>
              </motion.h1>

              {/* Subheading */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.55, delay: 0.22 }}
                className="text-base sm:text-lg leading-relaxed max-w-xl"
                style={{ color: "rgba(255,255,255,0.6)" }}
              >
                Master AIML concepts with interactive lessons, coding
                playgrounds, mini-games, quizzes, and simulations. Level up from
                zero to expert at your own pace.
              </motion.p>

              {/* CTA buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.34 }}
                className="flex flex-wrap items-center gap-4"
              >
                <Link
                  to="/learn"
                  className="neon-btn-primary flex items-center gap-2 px-8 py-3.5 text-base"
                  data-ocid="home.hero.start_learning.primary_button"
                >
                  <Zap className="w-5 h-5" />
                  Start Learning
                </Link>
                <button
                  type="button"
                  className="neon-btn-cyan flex items-center gap-2 px-8 py-3.5 text-base"
                  data-ocid="home.hero.watch_demo.secondary_button"
                  onClick={() =>
                    document
                      .getElementById("features")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                >
                  <Play className="w-5 h-5" />
                  Watch Demo
                </button>
              </motion.div>

              {/* Stats */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.55 }}
                className="flex flex-wrap gap-6 pt-2"
              >
                {STATS.map(({ value, label, icon: Icon }) => (
                  <div key={label} className="flex items-center gap-2">
                    <Icon className="w-4 h-4" style={{ color: "#22D3EE" }} />
                    <div>
                      <div
                        className="font-accent font-bold text-sm"
                        style={{ color: "#a78bfa" }}
                      >
                        {value}
                      </div>
                      <div
                        className="text-xs"
                        style={{ color: "rgba(255,255,255,0.4)" }}
                      >
                        {label}
                      </div>
                    </div>
                  </div>
                ))}
              </motion.div>
            </div>

            {/* ── Right: Brain visual ── */}
            <motion.div
              initial={{ opacity: 0, scale: 0.88 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.9, delay: 0.2, ease: "easeOut" }}
              className="hidden lg:flex items-center justify-center relative"
              data-ocid="home.hero.brain_visual"
            >
              {/* Outer ambient ring */}
              <div
                className="absolute w-[380px] h-[380px] rounded-full pointer-events-none"
                style={{
                  background:
                    "radial-gradient(circle, rgba(124,58,237,0.18) 0%, transparent 70%)",
                  animation: "pulse-glow 4s ease-in-out infinite",
                }}
              />
              {/* Spinning orbit ring */}
              <div
                className="absolute w-[320px] h-[320px] rounded-full pointer-events-none"
                style={{
                  border: "1px dashed rgba(34,211,238,0.18)",
                  animation: "spin 18s linear infinite",
                }}
              />
              <div
                className="absolute w-[260px] h-[260px] rounded-full pointer-events-none"
                style={{
                  border: "1px dashed rgba(124,58,237,0.15)",
                  animation: "spin 12s linear infinite reverse",
                }}
              />

              {/* Hero image */}
              <div
                className="relative rounded-3xl overflow-hidden animate-float"
                style={{
                  boxShadow:
                    "0 0 70px rgba(124,58,237,0.45), 0 0 140px rgba(34,211,238,0.18)",
                  border: "1px solid rgba(124,58,237,0.35)",
                }}
              >
                <img
                  src="/assets/generated/hero-ai-brain.dim_600x600.png"
                  alt="AI Brain visualization"
                  className="w-[300px] h-[300px] object-cover"
                  style={{ filter: "brightness(1.1) saturate(1.2)" }}
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "linear-gradient(135deg, rgba(124,58,237,0.12) 0%, transparent 50%, rgba(34,211,238,0.12) 100%)",
                  }}
                />
              </div>

              {/* Floating icon chips */}
              {FLOATING_CHIPS.map(
                ({ icon: Icon, color, label, x, y, delay }) => (
                  <motion.div
                    key={label}
                    className={`absolute ${x} ${y} w-12 h-12 rounded-xl flex items-center justify-center`}
                    style={{
                      background: `${color}18`,
                      border: `1px solid ${color}40`,
                      boxShadow: `0 0 18px ${color}30`,
                      animation: `float ${3.5 + delay}s ease-in-out ${delay * 0.5}s infinite`,
                    }}
                    whileHover={{ scale: 1.2 }}
                    title={label}
                  >
                    <Icon className="w-5 h-5" style={{ color }} />
                  </motion.div>
                ),
              )}

              {/* Neural score pill */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9 }}
                className="absolute -bottom-4 -right-6 flex items-center gap-2 px-4 py-2.5 rounded-xl"
                style={{
                  background: "rgba(11,16,38,0.92)",
                  border: "1px solid rgba(34,211,238,0.35)",
                  boxShadow: "0 0 20px rgba(34,211,238,0.2)",
                  backdropFilter: "blur(12px)",
                }}
              >
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center"
                  style={{ background: "rgba(34,211,238,0.15)" }}
                >
                  <Brain className="w-4 h-4" style={{ color: "#22D3EE" }} />
                </div>
                <div>
                  <div
                    className="font-accent font-bold text-xs"
                    style={{ color: "#22D3EE" }}
                  >
                    Neural Score
                  </div>
                  <div
                    className="text-[10px]"
                    style={{ color: "rgba(255,255,255,0.5)" }}
                  >
                    98% accuracy
                  </div>
                </div>
              </motion.div>

              {/* Level chip */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.0 }}
                className="absolute -top-4 -left-4 flex items-center gap-2 px-3 py-2 rounded-xl"
                style={{
                  background: "rgba(11,16,38,0.92)",
                  border: "1px solid rgba(124,58,237,0.4)",
                  boxShadow: "0 0 20px rgba(124,58,237,0.25)",
                  backdropFilter: "blur(12px)",
                }}
              >
                <Trophy className="w-4 h-4" style={{ color: "#f59e0b" }} />
                <div>
                  <div
                    className="font-accent font-bold text-xs"
                    style={{ color: "#a78bfa" }}
                  >
                    Level 12
                  </div>
                  <div
                    className="text-[10px]"
                    style={{ color: "rgba(255,255,255,0.45)" }}
                  >
                    ML Master
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ══ FEATURES SECTION ══ */}
      <section
        id="features"
        className="relative py-24"
        style={{
          zIndex: 1,
          background:
            "linear-gradient(180deg, rgba(124,58,237,0.04) 0%, rgba(11,16,38,0) 100%)",
          borderTop: "1px solid rgba(255,255,255,0.04)",
        }}
        data-ocid="home.features.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-14"
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-accent uppercase tracking-widest mb-5"
              style={{
                background: "rgba(34,211,238,0.08)",
                border: "1px solid rgba(34,211,238,0.22)",
                color: "#22D3EE",
              }}
            >
              Platform Features
            </div>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              Why{" "}
              <span
                style={{
                  background: "linear-gradient(135deg, #a78bfa, #22D3EE)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                AIML Quest?
              </span>
            </h2>
            <p
              className="max-w-xl mx-auto text-base"
              style={{ color: "rgba(255,255,255,0.55)" }}
            >
              A complete learning ecosystem combining structured lessons,
              hands-on practice, and gamified challenges designed to make AI/ML
              genuinely fun to learn.
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map(
              ({ icon: Icon, title, desc, color, badge, link }, i) => (
                <motion.div
                  key={title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.45, delay: i * 0.08 }}
                  className="glass glass-hover rounded-2xl p-6 group cursor-pointer"
                  data-ocid={`home.features.item.${i + 1}`}
                >
                  <div className="flex items-start justify-between mb-5">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{
                        background: `${color}18`,
                        border: `1px solid ${color}38`,
                        boxShadow: `0 0 18px ${color}22`,
                      }}
                    >
                      <Icon
                        className="w-6 h-6 animate-pulse-glow"
                        style={{ color }}
                      />
                    </div>
                    <span
                      className="text-xs font-accent font-medium px-2.5 py-1 rounded-full tracking-wider"
                      style={{
                        background: `${color}15`,
                        border: `1px solid ${color}30`,
                        color,
                      }}
                    >
                      {badge}
                    </span>
                  </div>

                  <h3 className="font-display font-semibold text-lg text-white mb-2 transition-smooth">
                    {title}
                  </h3>
                  <p
                    className="text-sm leading-relaxed mb-4"
                    style={{ color: "rgba(255,255,255,0.55)" }}
                  >
                    {desc}
                  </p>

                  <Link
                    to={link as "/"}
                    className="flex items-center gap-1.5 text-xs font-medium transition-smooth opacity-60 group-hover:opacity-100"
                    style={{ color }}
                    data-ocid={`home.features.item.${i + 1}.link`}
                  >
                    Learn more{" "}
                    <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform duration-200" />
                  </Link>
                </motion.div>
              ),
            )}
          </div>
        </div>
      </section>

      {/* ══ LEARNING JOURNEY SECTION ══ */}
      <section
        className="relative py-24"
        style={{
          zIndex: 1,
          background:
            "linear-gradient(180deg, rgba(11,16,38,0) 0%, rgba(124,58,237,0.06) 50%, rgba(11,16,38,0) 100%)",
          borderTop: "1px solid rgba(124,58,237,0.08)",
        }}
        data-ocid="home.learning_journey.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-14"
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-accent uppercase tracking-widest mb-5"
              style={{
                background: "rgba(124,58,237,0.1)",
                border: "1px solid rgba(124,58,237,0.28)",
                color: "#a78bfa",
              }}
            >
              Structured Curriculum
            </div>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-4">
              Your{" "}
              <span
                style={{
                  background: "linear-gradient(135deg, #7C3AED, #a855f7)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Learning Journey
              </span>
            </h2>
            <p
              className="max-w-lg mx-auto text-base"
              style={{ color: "rgba(255,255,255,0.55)" }}
            >
              Progress from fundamentals to cutting-edge AI techniques at your
              own pace. Unlock new topics as you advance.
            </p>
          </motion.div>

          {/* Level pills — horizontal on desktop */}
          <div className="flex flex-col md:flex-row gap-4 mb-10 justify-center">
            {LEARNING_LEVELS.map(
              ({ level, icon: LevelIcon, color, badge, desc }, i) => (
                <motion.div
                  key={level}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                  className="glass glass-hover flex items-center gap-4 px-6 py-4 rounded-2xl flex-1"
                  style={{
                    maxWidth: "360px",
                    border: `1px solid ${color}22`,
                    margin: "0 auto",
                  }}
                  data-ocid={`home.learning_journey.level.${i + 1}`}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      background: `${color}18`,
                      border: `1px solid ${color}30`,
                      boxShadow: `0 0 16px ${color}22`,
                    }}
                  >
                    <LevelIcon className="w-6 h-6" style={{ color }} />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-display font-bold text-white text-sm">
                        {level}
                      </span>
                      <span
                        className="text-[10px] font-accent px-2 py-0.5 rounded-full"
                        style={{
                          background: `${color}18`,
                          border: `1px solid ${color}30`,
                          color,
                        }}
                      >
                        {badge}
                      </span>
                    </div>
                    <p
                      className="text-xs leading-relaxed truncate"
                      style={{ color: "rgba(255,255,255,0.5)" }}
                    >
                      {desc}
                    </p>
                  </div>
                </motion.div>
              ),
            )}
          </div>

          {/* Expanded path cards */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {LEARNING_LEVELS.map(({ level, color, topics }, i) => (
              <motion.div
                key={level}
                initial={{
                  opacity: 0,
                  x: i === 0 ? -30 : i === 2 ? 30 : 0,
                  y: i === 1 ? 20 : 0,
                }}
                whileInView={{ opacity: 1, x: 0, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.12 }}
                className="glass rounded-2xl p-6"
                style={{ border: `1px solid ${color}20` }}
                data-ocid={`home.learning_path.level.${i + 1}`}
              >
                <div className="flex items-center gap-3 mb-5">
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center font-accent font-bold text-sm"
                    style={{
                      background: `${color}18`,
                      color,
                      border: `1px solid ${color}30`,
                    }}
                  >
                    {i + 1}
                  </div>
                  <div>
                    <div className="font-display font-bold text-white text-sm">
                      {level}
                    </div>
                    <div className="text-xs" style={{ color }}>
                      {topics.length} topics
                    </div>
                  </div>
                </div>
                <ul className="space-y-2.5 mb-5">
                  {topics.map((t) => (
                    <li
                      key={t}
                      className="flex items-center gap-2.5 text-sm"
                      style={{ color: "rgba(255,255,255,0.65)" }}
                    >
                      <div
                        className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                        style={{ background: color }}
                      />
                      {t}
                    </li>
                  ))}
                </ul>
                <Link
                  to="/learn"
                  className="flex items-center gap-2 text-sm font-medium transition-smooth hover:gap-3"
                  style={{ color }}
                  data-ocid={`home.learning_path.level.${i + 1}.link`}
                >
                  Start {level} <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Journey CTA */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.45 }}
            className="flex justify-center"
          >
            <Link
              to="/learn"
              className="neon-btn-primary flex items-center gap-2.5 px-10 py-4 text-base"
              data-ocid="home.learning_journey.start_journey.primary_button"
            >
              <Rocket className="w-5 h-5" />
              Start Your Journey
            </Link>
          </motion.div>
        </div>
      </section>

      {/* ══ TESTIMONIAL / SOCIAL PROOF ══ */}
      <section
        className="relative py-16 overflow-hidden"
        style={{
          zIndex: 1,
          borderTop: "1px solid rgba(255,255,255,0.04)",
          background: "rgba(11,16,38,0.5)",
        }}
        data-ocid="home.social_proof.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <p
              className="text-sm font-accent uppercase tracking-widest mb-8"
              style={{ color: "rgba(255,255,255,0.3)" }}
            >
              Trusted by learners worldwide
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-2xl mx-auto">
              {[
                { value: "1,200+", label: "Active Learners" },
                { value: "50+", label: "AI/ML Topics" },
                { value: "20+", label: "Mini Games" },
                { value: "95%", label: "Completion Rate" },
              ].map(({ value, label }, i) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="text-center"
                  data-ocid={`home.social_proof.stat.${i + 1}`}
                >
                  <div
                    className="text-2xl sm:text-3xl font-accent font-bold mb-1"
                    style={{
                      background: "linear-gradient(135deg, #a78bfa, #22D3EE)",
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                      backgroundClip: "text",
                    }}
                  >
                    {value}
                  </div>
                  <div
                    className="text-xs"
                    style={{ color: "rgba(255,255,255,0.4)" }}
                  >
                    {label}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ══ CTA SECTION ══ */}
      <section
        className="relative py-24"
        style={{
          zIndex: 1,
          borderTop: "1px solid rgba(124,58,237,0.1)",
        }}
        data-ocid="home.cta.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65 }}
            className="relative rounded-3xl p-12 sm:p-16 text-center overflow-hidden"
            style={{
              background:
                "linear-gradient(135deg, rgba(124,58,237,0.18) 0%, rgba(11,16,38,0.95) 50%, rgba(34,211,238,0.12) 100%)",
              border: "1px solid rgba(124,58,237,0.3)",
              boxShadow:
                "0 0 80px rgba(124,58,237,0.18), 0 0 160px rgba(34,211,238,0.06)",
            }}
          >
            {/* Decorative glows */}
            <div
              className="absolute -top-24 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full pointer-events-none"
              style={{
                background:
                  "radial-gradient(circle, rgba(124,58,237,0.22) 0%, transparent 70%)",
              }}
            />
            <div
              className="absolute -bottom-24 right-0 w-64 h-64 rounded-full pointer-events-none"
              style={{
                background:
                  "radial-gradient(circle, rgba(34,211,238,0.14) 0%, transparent 70%)",
              }}
            />

            <div className="relative z-10">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-6 mx-auto"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(124,58,237,0.3), rgba(34,211,238,0.2))",
                  border: "1px solid rgba(124,58,237,0.4)",
                  boxShadow: "0 0 30px rgba(124,58,237,0.4)",
                }}
              >
                <Brain className="w-8 h-8 text-white" />
              </motion.div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-display font-bold text-white mb-5">
                Ready to Master{" "}
                <span
                  style={{
                    background:
                      "linear-gradient(135deg, #a78bfa 0%, #22D3EE 100%)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  AI &amp; ML?
                </span>
              </h2>
              <p
                className="max-w-lg mx-auto text-base mb-10 leading-relaxed"
                style={{ color: "rgba(255,255,255,0.6)" }}
              >
                Join thousands of learners building the future with AI. No prior
                experience needed — just curiosity and the drive to learn.
              </p>
              <div className="flex flex-wrap items-center justify-center gap-4">
                <Link
                  to="/learn"
                  className="neon-btn-primary flex items-center gap-2.5 px-9 py-4 text-base"
                  data-ocid="home.cta.get_started.primary_button"
                >
                  <Brain className="w-5 h-5" />
                  Get Started Free
                </Link>
                <Link
                  to="/practice"
                  className="neon-btn-cyan flex items-center gap-2.5 px-9 py-4 text-base"
                  data-ocid="home.cta.try_playground.secondary_button"
                >
                  <Code2 className="w-5 h-5" />
                  Try Playground
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
