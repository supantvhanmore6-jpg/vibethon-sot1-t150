import * as Dialog from "@radix-ui/react-dialog";
import { Link } from "@tanstack/react-router";
import {
  BookOpen,
  Brain,
  ChevronRight,
  Eye,
  GitBranch,
  Globe,
  HelpCircle,
  Layers,
  Lock,
  MessageSquare,
  Play,
  Search,
  Shuffle,
  Sparkles,
  Star,
  TrendingUp,
  X,
  Zap,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import ParticleBackground from "../components/ParticleBackground";

// ─── Types ────────────────────────────────────────────────────────────────────
type Level = "All" | "Beginner" | "Intermediate" | "Advanced";

interface Topic {
  id: string;
  title: string;
  level: Exclude<Level, "All">;
  icon: React.ReactNode;
  summary: string;
  explanation: string;
  example: string;
  locked: boolean;
  hasDecisionTreeDemo?: boolean;
}

// ─── Data ─────────────────────────────────────────────────────────────────────
const TOPICS: Topic[] = [
  // Beginner
  {
    id: "what-is-ai",
    title: "What is AI?",
    level: "Beginner",
    icon: <Brain className="w-5 h-5" />,
    summary: "Explore how machines simulate human intelligence and reasoning.",
    explanation:
      "Artificial Intelligence is the science of building machines that can think, learn, and solve problems like humans. AI systems process data, find patterns, and make decisions — sometimes better than humans can. From virtual assistants to medical diagnosis tools, AI is already shaping our world.",
    example:
      "Siri and Google Assistant use AI to understand your voice commands and respond with relevant answers in real-time.",
    locked: false,
  },
  {
    id: "what-is-ml",
    title: "What is Machine Learning?",
    level: "Beginner",
    icon: <TrendingUp className="w-5 h-5" />,
    summary: "Discover how machines learn from data instead of explicit rules.",
    explanation:
      "Machine Learning is a branch of AI where systems automatically learn and improve from experience without being explicitly programmed. You feed the machine data, it finds patterns, and uses those patterns to make predictions on new data.",
    example:
      "Email spam filters learn from millions of spam examples to automatically detect and block unwanted messages.",
    locked: false,
  },
  {
    id: "supervised-learning",
    title: "Supervised Learning",
    level: "Beginner",
    icon: <BookOpen className="w-5 h-5" />,
    summary: "Train models using labeled data to predict outcomes accurately.",
    explanation:
      "Supervised learning trains models using examples that have both inputs and known correct outputs (labels). The model learns to map inputs to outputs and can then predict labels for new, unseen data.",
    example:
      "Predicting house prices: the model trains on past sales data (input: size, location; output: price) and then predicts prices for new listings.",
    locked: false,
  },
  {
    id: "unsupervised-learning",
    title: "Unsupervised Learning",
    level: "Beginner",
    icon: <Shuffle className="w-5 h-5" />,
    summary: "Find hidden patterns in data without labeled examples.",
    explanation:
      "Unsupervised learning finds structure in data that has no labels. The algorithm groups similar items together or discovers hidden relationships — no human guidance needed.",
    example:
      "An e-commerce platform groups customers into segments (bargain hunters, loyal buyers, occasional shoppers) to tailor marketing — without anyone labeling the groups first.",
    locked: false,
  },
  {
    id: "reinforcement-learning",
    title: "Reinforcement Learning",
    level: "Beginner",
    icon: <Star className="w-5 h-5" />,
    summary: "Teach agents to make decisions through rewards and penalties.",
    explanation:
      "Reinforcement learning trains an agent by rewarding good actions and penalizing bad ones. Over many trials, the agent learns a strategy (policy) that maximizes its total reward — similar to how humans learn from trial and error.",
    example:
      "AI game agents like AlphaGo play millions of games against themselves, learning from wins and losses until they surpass human champions.",
    locked: false,
  },
  {
    id: "datasets-features-labels",
    title: "Datasets, Features & Labels",
    level: "Beginner",
    icon: <Layers className="w-5 h-5" />,
    summary: "Understand the building blocks: raw data, features, and targets.",
    explanation:
      "A dataset is a collection of examples. Each example has features (measurable properties) and a label (the answer you want to predict). Quality data with well-engineered features is the foundation of every ML model.",
    example:
      "Iris dataset: features are petal length, petal width, sepal length, sepal width; the label is the flower species (Setosa, Versicolor, or Virginica).",
    locked: false,
  },
  // Intermediate
  {
    id: "linear-regression",
    title: "Linear Regression",
    level: "Intermediate",
    icon: <TrendingUp className="w-5 h-5" />,
    summary: "Model relationships between variables with a best-fit line.",
    explanation:
      "Linear regression finds the straight line that best fits a set of data points, minimizing the distance between predictions and actual values. It's the simplest and most interpretable ML model for predicting numeric outcomes.",
    example:
      "Predicting salary based on years of experience: a straight line drawn through historical data gives a formula for estimating new salaries.",
    locked: false,
  },
  {
    id: "decision-trees",
    title: "Decision Trees",
    level: "Intermediate",
    icon: <GitBranch className="w-5 h-5" />,
    summary:
      "Flowchart-like models that split data based on feature conditions.",
    explanation:
      "A decision tree asks a series of yes/no questions about the data, branching at each node until it reaches a prediction at the leaves. They're easy to visualize and explain.",
    example:
      "A loan approval system asks: Is income > $50k? → Is credit score > 700? → Is debt-to-income < 30%? Each branch leads to Approve or Reject.",
    locked: false,
    hasDecisionTreeDemo: true,
  },
  {
    id: "knn",
    title: "K-Nearest Neighbors (KNN)",
    level: "Intermediate",
    icon: <Globe className="w-5 h-5" />,
    summary:
      "Classify data by looking at the closest neighbors in feature space.",
    explanation:
      "KNN classifies a new point by finding the K most similar existing data points and taking a majority vote. It's simple, intuitive, and requires no training phase — just store the data.",
    example:
      "Recommending movies: KNN finds K users with similar watch history to you and suggests films they loved that you haven't seen.",
    locked: false,
  },
  {
    id: "classification-vs-regression",
    title: "Classification vs Regression",
    level: "Intermediate",
    icon: <Sparkles className="w-5 h-5" />,
    summary: "Know when to predict a category versus a continuous number.",
    explanation:
      "Classification predicts which category an input belongs to (discrete output), while regression predicts a continuous numeric value. Choosing the right task type is crucial for picking the right algorithm.",
    example:
      "Spam detection is classification (spam / not spam). Predicting tomorrow's temperature is regression (22.5°C).",
    locked: false,
  },
  {
    id: "neural-networks",
    title: "Neural Networks",
    level: "Intermediate",
    icon: <Brain className="w-5 h-5" />,
    summary: "Layers of interconnected nodes inspired by the human brain.",
    explanation:
      "Neural networks are layers of mathematical nodes (neurons) connected by weighted edges. Data flows forward through layers, getting transformed at each step. The network adjusts weights during training to minimize errors.",
    example:
      "Recognizing handwritten postal codes: a neural network maps pixel values → features → digit classification in milliseconds.",
    locked: false,
  },
  // Advanced
  {
    id: "deep-learning",
    title: "Deep Learning",
    level: "Advanced",
    icon: <Layers className="w-5 h-5" />,
    summary:
      "Neural networks with many layers that learn rich representations.",
    explanation:
      "Deep learning uses neural networks with dozens or hundreds of layers to automatically learn hierarchical features from raw data. Each layer learns increasingly abstract concepts — from edges to shapes to objects.",
    example:
      "Image classification: early layers detect edges, middle layers detect shapes, deep layers recognize full objects like cats, cars, or tumors.",
    locked: false,
  },
  {
    id: "cnn",
    title: "Convolutional Neural Networks",
    level: "Advanced",
    icon: <Eye className="w-5 h-5" />,
    summary: "Specialized networks that excel at image recognition tasks.",
    explanation:
      "CNNs use sliding filter windows (convolutions) to scan images and detect local patterns regardless of their position. Pooling layers reduce spatial dimensions while preserving key features.",
    example:
      "Medical imaging: CNNs analyze MRI scans with radiologist-level accuracy, detecting tumors in seconds from images that take doctors hours to review.",
    locked: true,
  },
  {
    id: "nlp",
    title: "Natural Language Processing",
    level: "Advanced",
    icon: <MessageSquare className="w-5 h-5" />,
    summary: "Enable computers to understand and generate human language.",
    explanation:
      "NLP combines linguistics and ML to let computers read, understand, and produce text. Modern NLP uses transformer models that learn context across long sequences of words.",
    example:
      "ChatGPT and Google Translate both use NLP — one generates conversational responses, the other maps meaning across 130+ languages.",
    locked: true,
  },
  {
    id: "computer-vision",
    title: "Computer Vision",
    level: "Advanced",
    icon: <Eye className="w-5 h-5" />,
    summary: "Process and interpret visual information from the real world.",
    explanation:
      "Computer vision gives machines the ability to see and understand images and video — detecting objects, tracking movement, reading text, and reconstructing 3D scenes.",
    example:
      "Autonomous vehicles use computer vision to detect lane markings, pedestrians, traffic signs, and other cars in real-time at highway speeds.",
    locked: true,
  },
  {
    id: "recommendation-systems",
    title: "Recommendation Systems",
    level: "Advanced",
    icon: <Star className="w-5 h-5" />,
    summary:
      "Suggest relevant content using collaborative and content-based filtering.",
    explanation:
      "Recommendation systems predict what a user will like based on past behavior and similarity to other users. They combine collaborative filtering (what similar users liked) with content-based filtering (item attributes).",
    example:
      "Netflix uses your watch history + 200 million other users' patterns to suggest shows you'll love — driving 80% of content watched.",
    locked: true,
  },
];

const LEVEL_META = {
  Beginner: {
    color: "#10b981",
    bg: "rgba(16,185,129,0.08)",
    border: "rgba(16,185,129,0.3)",
    glow: "rgba(16,185,129,0.2)",
    label: "Beginner",
  },
  Intermediate: {
    color: "#f59e0b",
    bg: "rgba(245,158,11,0.08)",
    border: "rgba(245,158,11,0.3)",
    glow: "rgba(245,158,11,0.2)",
    label: "Intermediate",
  },
  Advanced: {
    color: "#f43f5e",
    bg: "rgba(244,63,94,0.08)",
    border: "rgba(244,63,94,0.3)",
    glow: "rgba(244,63,94,0.2)",
    label: "Advanced",
  },
};

const COMPLETED_IDS = ["what-is-ai", "what-is-ml", "supervised-learning"];
const LEVEL_FILTERS: Level[] = ["All", "Beginner", "Intermediate", "Advanced"];

// ─── Decision Tree Demo ───────────────────────────────────────────────────────
function DecisionTreeDemo() {
  const [answers, setAnswers] = useState<{
    income: boolean | null;
    credit: boolean | null;
  }>({
    income: null,
    credit: null,
  });

  const result =
    answers.income === false
      ? "rejected"
      : answers.income === true && answers.credit === false
        ? "review"
        : answers.income === true && answers.credit === true
          ? "approved"
          : null;

  const reset = () => setAnswers({ income: null, credit: null });

  const nodeStyle = (active: boolean, color: string) => ({
    background: active ? `${color}20` : "rgba(255,255,255,0.04)",
    border: `1px solid ${active ? color : "rgba(255,255,255,0.1)"}`,
    boxShadow: active ? `0 0 16px ${color}40` : "none",
    transition: "all 0.3s ease",
  });

  return (
    <div
      className="rounded-xl p-4 mt-4"
      style={{
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.07)",
      }}
    >
      <p
        className="text-xs font-accent uppercase tracking-widest mb-4"
        style={{ color: "#a78bfa" }}
      >
        Interactive Demo — Loan Approval Tree
      </p>

      {/* Root node */}
      <div className="flex flex-col items-center gap-2">
        <div
          className="px-4 py-2.5 rounded-xl text-center text-xs font-medium max-w-xs w-full"
          style={nodeStyle(true, "#7C3AED")}
        >
          <span style={{ color: "#a78bfa" }}>Root</span>
          <div className="text-white mt-0.5">
            Is annual income &gt; $50,000?
          </div>
          {answers.income === null && (
            <div className="flex gap-2 justify-center mt-2">
              <button
                type="button"
                onClick={() => setAnswers({ income: true, credit: null })}
                className="px-3 py-1 rounded-lg text-xs font-medium transition-smooth"
                style={{
                  background: "rgba(16,185,129,0.2)",
                  color: "#10b981",
                  border: "1px solid rgba(16,185,129,0.4)",
                }}
                data-ocid="learn.dt_demo.income_yes.button"
              >
                ✓ Yes
              </button>
              <button
                type="button"
                onClick={() => setAnswers({ income: false, credit: null })}
                className="px-3 py-1 rounded-lg text-xs font-medium transition-smooth"
                style={{
                  background: "rgba(244,63,94,0.2)",
                  color: "#f43f5e",
                  border: "1px solid rgba(244,63,94,0.4)",
                }}
                data-ocid="learn.dt_demo.income_no.button"
              >
                ✗ No
              </button>
            </div>
          )}
          {answers.income !== null && (
            <div
              className="mt-1.5 text-xs"
              style={{ color: answers.income ? "#10b981" : "#f43f5e" }}
            >
              {answers.income
                ? "✓ Yes — income qualifies"
                : "✗ No — income too low"}
            </div>
          )}
        </div>

        {/* Branch lines */}
        <div className="flex gap-8 items-start w-full justify-center">
          {/* NO branch */}
          <div
            className="flex flex-col items-center gap-1"
            style={{ opacity: answers.income === true ? 0.3 : 1 }}
          >
            <div className="w-px h-5" style={{ background: "#f43f5e60" }} />
            <div
              className="px-3 py-2 rounded-xl text-center text-xs w-28"
              style={nodeStyle(answers.income === false, "#f43f5e")}
            >
              <div className="font-medium" style={{ color: "#f43f5e" }}>
                ❌ REJECTED
              </div>
              <div className="text-white/50 mt-0.5">Insufficient income</div>
            </div>
          </div>

          {/* YES branch */}
          <div
            className="flex flex-col items-center gap-1"
            style={{ opacity: answers.income === false ? 0.3 : 1 }}
          >
            <div className="w-px h-5" style={{ background: "#10b98160" }} />
            <div
              className="px-3 py-2 rounded-xl text-center text-xs max-w-[150px]"
              style={nodeStyle(answers.income === true, "#7C3AED")}
            >
              <span style={{ color: "#a78bfa" }}>Node 2</span>
              <div className="text-white mt-0.5">Credit score &gt; 700?</div>
              {answers.income === true && answers.credit === null && (
                <div className="flex gap-1 justify-center mt-2">
                  <button
                    type="button"
                    onClick={() => setAnswers((p) => ({ ...p, credit: true }))}
                    className="px-2 py-0.5 rounded text-xs transition-smooth"
                    style={{
                      background: "rgba(16,185,129,0.2)",
                      color: "#10b981",
                      border: "1px solid rgba(16,185,129,0.4)",
                    }}
                    data-ocid="learn.dt_demo.credit_yes.button"
                  >
                    ✓ Yes
                  </button>
                  <button
                    type="button"
                    onClick={() => setAnswers((p) => ({ ...p, credit: false }))}
                    className="px-2 py-0.5 rounded text-xs transition-smooth"
                    style={{
                      background: "rgba(244,63,94,0.2)",
                      color: "#f43f5e",
                      border: "1px solid rgba(244,63,94,0.4)",
                    }}
                    data-ocid="learn.dt_demo.credit_no.button"
                  >
                    ✗ No
                  </button>
                </div>
              )}
            </div>

            {/* Leaf nodes */}
            {answers.income === true && answers.credit !== null && (
              <div className="flex gap-3 mt-1">
                <div
                  className="flex flex-col items-center gap-1"
                  style={{ opacity: answers.credit === true ? 0.3 : 1 }}
                >
                  <div
                    className="w-px h-4"
                    style={{ background: "#f59e0b60" }}
                  />
                  <div
                    className="px-2 py-1.5 rounded-lg text-center text-xs w-24"
                    style={nodeStyle(answers.credit === false, "#f59e0b")}
                  >
                    <div className="font-medium" style={{ color: "#f59e0b" }}>
                      ⚠ REVIEW
                    </div>
                    <div className="text-white/50 mt-0.5 text-[10px]">
                      Manual review
                    </div>
                  </div>
                </div>
                <div
                  className="flex flex-col items-center gap-1"
                  style={{ opacity: answers.credit === false ? 0.3 : 1 }}
                >
                  <div
                    className="w-px h-4"
                    style={{ background: "#10b98160" }}
                  />
                  <div
                    className="px-2 py-1.5 rounded-lg text-center text-xs w-24"
                    style={nodeStyle(answers.credit === true, "#10b981")}
                  >
                    <div className="font-medium" style={{ color: "#10b981" }}>
                      ✅ APPROVED
                    </div>
                    <div className="text-white/50 mt-0.5 text-[10px]">
                      Loan granted
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Result + reset */}
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-4 flex items-center justify-between rounded-xl px-4 py-3"
            style={{
              background:
                result === "approved"
                  ? "rgba(16,185,129,0.1)"
                  : result === "rejected"
                    ? "rgba(244,63,94,0.1)"
                    : "rgba(245,158,11,0.1)",
              border: `1px solid ${result === "approved" ? "rgba(16,185,129,0.3)" : result === "rejected" ? "rgba(244,63,94,0.3)" : "rgba(245,158,11,0.3)"}`,
            }}
          >
            <span className="text-sm font-medium text-white">
              Decision:{" "}
              <span
                style={{
                  color:
                    result === "approved"
                      ? "#10b981"
                      : result === "rejected"
                        ? "#f43f5e"
                        : "#f59e0b",
                }}
              >
                {result === "approved"
                  ? "✅ LOAN APPROVED"
                  : result === "rejected"
                    ? "❌ LOAN REJECTED"
                    : "⚠ NEEDS MANUAL REVIEW"}
              </span>
            </span>
            <button
              type="button"
              onClick={reset}
              className="text-xs px-3 py-1 rounded-lg transition-smooth"
              style={{
                background: "rgba(255,255,255,0.08)",
                color: "rgba(255,255,255,0.6)",
              }}
              data-ocid="learn.dt_demo.reset.button"
            >
              Reset
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Topic Detail Modal ───────────────────────────────────────────────────────
function TopicModal({ topic, onClose }: { topic: Topic; onClose: () => void }) {
  const meta = LEVEL_META[topic.level];

  return (
    <Dialog.Portal>
      <Dialog.Overlay
        className="fixed inset-0 z-50"
        style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(8px)" }}
        data-ocid="learn.modal.overlay"
      />
      <Dialog.Content
        className="fixed z-50 inset-0 flex items-center justify-center p-4"
        data-ocid="learn.modal.dialog"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="glass rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
          style={{
            border: `1px solid ${meta.border}`,
            boxShadow: `0 0 50px ${meta.glow}`,
          }}
        >
          {/* Header */}
          <div
            className="sticky top-0 flex items-start justify-between p-6 pb-4"
            style={{
              background: "rgba(11,16,38,0.95)",
              backdropFilter: "blur(12px)",
              borderBottom: `1px solid ${meta.border}40`,
            }}
          >
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="text-xs font-accent uppercase tracking-widest px-2.5 py-1 rounded-full"
                  style={{
                    background: meta.bg,
                    color: meta.color,
                    border: `1px solid ${meta.border}`,
                  }}
                >
                  {topic.level}
                </span>
                {topic.locked && (
                  <span
                    className="text-xs px-2.5 py-1 rounded-full flex items-center gap-1"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      color: "rgba(255,255,255,0.4)",
                      border: "1px solid rgba(255,255,255,0.1)",
                    }}
                  >
                    <Lock className="w-3 h-3" /> Locked
                  </span>
                )}
              </div>
              <Dialog.Title className="text-xl font-display font-bold text-white">
                {topic.title}
              </Dialog.Title>
            </div>
            <Dialog.Close asChild>
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl transition-smooth hover:bg-white/[0.08]"
                style={{ color: "rgba(255,255,255,0.5)" }}
                data-ocid="learn.modal.close_button"
              >
                <X className="w-5 h-5" />
              </button>
            </Dialog.Close>
          </div>

          {/* Body */}
          <div className="p-6 pt-4 space-y-5">
            {/* Illustration placeholder */}
            <div
              className="rounded-xl p-5 flex flex-col items-center justify-center gap-3 min-h-[100px]"
              style={{
                background: `linear-gradient(135deg, ${meta.bg}, rgba(255,255,255,0.02))`,
                border: `1px solid ${meta.border}40`,
              }}
            >
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{
                  background: meta.bg,
                  border: `1px solid ${meta.border}`,
                  color: meta.color,
                }}
              >
                <div className="scale-150">{topic.icon}</div>
              </div>
              <p
                className="text-xs text-center max-w-xs"
                style={{ color: "rgba(255,255,255,0.4)" }}
              >
                Visual diagram — {topic.title} concept illustration
              </p>
            </div>

            {/* Explanation */}
            <div>
              <h3
                className="text-sm font-accent uppercase tracking-widest mb-2"
                style={{ color: meta.color }}
              >
                What it is
              </h3>
              <p
                className="text-sm leading-relaxed"
                style={{ color: "rgba(255,255,255,0.75)" }}
              >
                {topic.explanation}
              </p>
            </div>

            {/* Real-life example */}
            <div
              className="rounded-xl p-4"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <p
                className="text-xs font-accent uppercase tracking-widest mb-2"
                style={{ color: "#22D3EE" }}
              >
                Real-World Example
              </p>
              <p
                className="text-sm leading-relaxed"
                style={{ color: "rgba(255,255,255,0.65)" }}
              >
                {topic.example}
              </p>
            </div>

            {/* Decision Tree Interactive Demo */}
            {topic.hasDecisionTreeDemo && <DecisionTreeDemo />}

            {/* Actions */}
            <div className="flex items-center gap-3 pt-2">
              <Link to="/practice">
                <button
                  type="button"
                  className="neon-btn-primary flex items-center gap-2 text-sm px-5 py-2.5"
                  data-ocid="learn.modal.try_demo.button"
                >
                  <Play className="w-4 h-4" />
                  Try Demo
                </button>
              </Link>
              <Dialog.Close asChild>
                <button
                  type="button"
                  onClick={onClose}
                  className="neon-btn-cyan flex items-center gap-2 text-sm px-5 py-2.5"
                  data-ocid="learn.modal.take_quiz.button"
                >
                  <HelpCircle className="w-4 h-4" />
                  Take Quiz
                </button>
              </Dialog.Close>
            </div>
          </div>
        </motion.div>
      </Dialog.Content>
    </Dialog.Portal>
  );
}

// ─── Topic Card ───────────────────────────────────────────────────────────────
function TopicCard({
  topic,
  index,
  onOpen,
}: {
  topic: Topic;
  index: number;
  onOpen: (topic: Topic) => void;
}) {
  const meta = LEVEL_META[topic.level];
  const isCompleted = COMPLETED_IDS.includes(topic.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.05 }}
      className="glass glass-hover rounded-2xl cursor-pointer"
      style={{
        border: isCompleted ? `1px solid ${meta.border}50` : undefined,
        opacity: topic.locked ? 0.65 : 1,
      }}
      onClick={() => !topic.locked && onOpen(topic)}
      data-ocid={`learn.topic.item.${index + 1}`}
    >
      <div className="p-5">
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: meta.bg,
              border: `1px solid ${meta.border}`,
              color: meta.color,
            }}
          >
            {topic.locked ? (
              <Lock
                className="w-4 h-4"
                style={{ color: "rgba(255,255,255,0.3)" }}
              />
            ) : (
              topic.icon
            )}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <h3
                className="font-display font-semibold text-sm leading-snug"
                style={{
                  color: topic.locked ? "rgba(255,255,255,0.35)" : "#fff",
                }}
              >
                {topic.title}
              </h3>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                {isCompleted && (
                  <span className="text-xs" style={{ color: meta.color }}>
                    ✓
                  </span>
                )}
                <span
                  className="text-[10px] font-accent uppercase px-2 py-0.5 rounded-full whitespace-nowrap"
                  style={{
                    background: meta.bg,
                    color: meta.color,
                    border: `1px solid ${meta.border}`,
                  }}
                >
                  {topic.level}
                </span>
              </div>
            </div>
            <p
              className="text-xs leading-relaxed"
              style={{ color: "rgba(255,255,255,0.45)" }}
            >
              {topic.summary}
            </p>
          </div>
        </div>

        {/* Footer */}
        {!topic.locked && (
          <div
            className="flex items-center justify-end mt-3 pt-3"
            style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
          >
            <span
              className="text-xs flex items-center gap-1 transition-smooth"
              style={{ color: meta.color }}
            >
              Open lesson <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        )}
      </div>
    </motion.div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function Learn() {
  const [activeFilter, setActiveFilter] = useState<Level>("All");
  const [search, setSearch] = useState("");
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);

  const filteredTopics = TOPICS.filter((t) => {
    const matchesLevel = activeFilter === "All" || t.level === activeFilter;
    const matchesSearch =
      !search ||
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.summary.toLowerCase().includes(search.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  const byLevel = {
    Beginner: filteredTopics.filter((t) => t.level === "Beginner"),
    Intermediate: filteredTopics.filter((t) => t.level === "Intermediate"),
    Advanced: filteredTopics.filter((t) => t.level === "Advanced"),
  };

  const completedCount = COMPLETED_IDS.length;
  const totalCount = TOPICS.length;
  const progressPct = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="relative min-h-screen" style={{ zIndex: 1 }}>
      <ParticleBackground />

      {/* ── Page Header ── */}
      <div
        className="relative py-14"
        style={{
          background: "rgba(124,58,237,0.04)",
          borderBottom: "1px solid rgba(124,58,237,0.15)",
          zIndex: 2,
        }}
        data-ocid="learn.header.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-2xl mx-auto"
          >
            <div
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-accent uppercase tracking-widest mb-4"
              style={{
                background: "rgba(124,58,237,0.1)",
                border: "1px solid rgba(124,58,237,0.25)",
                color: "#a78bfa",
              }}
            >
              <BookOpen className="w-3 h-3" />
              Learning Path
            </div>
            <h1 className="text-4xl sm:text-5xl font-display font-bold text-white mb-3">
              AIML <span className="text-gradient-hero">Learning Path</span>
            </h1>
            <p
              className="text-base mb-8"
              style={{ color: "rgba(255,255,255,0.55)" }}
            >
              Master AI and Machine Learning from beginner to expert with
              interactive lessons, demos, and quizzes.
            </p>

            {/* Search */}
            <div
              className="relative max-w-md mx-auto"
              data-ocid="learn.search.input"
            >
              <Search
                className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none"
                style={{ color: "rgba(255,255,255,0.35)" }}
              />
              <input
                type="text"
                placeholder="Search topics..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-3 rounded-xl text-sm text-white placeholder-white/30 outline-none transition-smooth"
                style={{
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  backdropFilter: "blur(8px)",
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = "rgba(124,58,237,0.5)";
                  e.currentTarget.style.boxShadow =
                    "0 0 20px rgba(124,58,237,0.2)";
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              />
            </div>
          </motion.div>
        </div>
      </div>

      {/* ── Progress + Stats ── */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.15 }}
        className="relative py-6 z-10"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}
        data-ocid="learn.progress.section"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto">
            {/* Progress bar */}
            <div className="glass rounded-2xl p-5 mb-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-display font-medium text-white">
                  Overall Progress
                </span>
                <span
                  className="text-xs font-accent"
                  style={{ color: "#a78bfa" }}
                >
                  {completedCount}/{totalCount} topics completed
                </span>
              </div>
              <div
                className="h-2.5 rounded-full overflow-hidden"
                style={{ background: "rgba(255,255,255,0.08)" }}
              >
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPct}%` }}
                  transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
                  className="h-full rounded-full"
                  style={{
                    background: "linear-gradient(90deg, #7C3AED, #22D3EE)",
                  }}
                />
              </div>
              <p
                className="text-xs mt-2"
                style={{ color: "rgba(255,255,255,0.4)" }}
              >
                {progressPct}% complete — keep going!
              </p>
            </div>

            {/* Stat pills */}
            <div
              className="flex items-center gap-2 flex-wrap"
              data-ocid="learn.stats.section"
            >
              {(["Beginner", "Intermediate", "Advanced"] as const).map(
                (level) => {
                  const meta = LEVEL_META[level];
                  const count = TOPICS.filter((t) => t.level === level).length;
                  return (
                    <div
                      key={level}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium"
                      style={{
                        background: meta.bg,
                        border: `1px solid ${meta.border}`,
                        color: meta.color,
                      }}
                    >
                      <div
                        className="w-1.5 h-1.5 rounded-full"
                        style={{ background: meta.color }}
                      />
                      {count} {level}
                    </div>
                  );
                },
              )}
              <div
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium"
                style={{
                  background: "rgba(124,58,237,0.08)",
                  border: "1px solid rgba(124,58,237,0.25)",
                  color: "#a78bfa",
                }}
              >
                <Zap className="w-3 h-3" />
                {completedCount} Completed
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ── Level Filter Tabs ── */}
      <div
        className="sticky top-16 z-20 py-4"
        style={{
          background: "rgba(11,16,38,0.93)",
          backdropFilter: "blur(16px)",
          borderBottom: "1px solid rgba(255,255,255,0.05)",
        }}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className="flex items-center gap-2 overflow-x-auto pb-1"
            data-ocid="learn.filter.tabs"
          >
            {LEVEL_FILTERS.map((level) => {
              const isActive = activeFilter === level;
              const meta = level !== "All" ? LEVEL_META[level] : null;
              return (
                <button
                  key={level}
                  type="button"
                  onClick={() => setActiveFilter(level)}
                  className="flex-shrink-0 px-4 py-2 rounded-xl font-display font-medium text-sm transition-smooth"
                  style={{
                    background: isActive
                      ? meta
                        ? meta.bg
                        : "rgba(124,58,237,0.12)"
                      : "transparent",
                    border: `1px solid ${isActive ? (meta ? meta.border : "rgba(124,58,237,0.35)") : "transparent"}`,
                    color: isActive
                      ? meta
                        ? meta.color
                        : "#a78bfa"
                      : "rgba(255,255,255,0.45)",
                    boxShadow: isActive
                      ? `0 0 12px ${meta ? meta.glow : "rgba(124,58,237,0.15)"}`
                      : "none",
                  }}
                  data-ocid={`learn.filter.${level.toLowerCase()}.tab`}
                >
                  {level}
                  {level !== "All" && (
                    <span
                      className="ml-1.5 text-xs px-1.5 py-0.5 rounded-full"
                      style={{
                        background:
                          isActive && meta
                            ? `${meta.color}20`
                            : "rgba(255,255,255,0.07)",
                        color:
                          isActive && meta
                            ? meta.color
                            : "rgba(255,255,255,0.3)",
                      }}
                    >
                      {TOPICS.filter((t) => t.level === level).length}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Topic Sections ── */}
      <div className="relative py-10 z-10" data-ocid="learn.topics.section">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${activeFilter}-${search}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {filteredTopics.length === 0 ? (
                <div
                  className="text-center py-20"
                  data-ocid="learn.empty_state"
                >
                  <div className="text-4xl mb-3">🔍</div>
                  <p className="font-display font-semibold text-white mb-1">
                    No topics found
                  </p>
                  <p
                    className="text-sm"
                    style={{ color: "rgba(255,255,255,0.4)" }}
                  >
                    Try a different search term or filter.
                  </p>
                </div>
              ) : (
                (["Beginner", "Intermediate", "Advanced"] as const).map(
                  (level) => {
                    const levelTopics = byLevel[level];
                    if (levelTopics.length === 0) return null;
                    const meta = LEVEL_META[level];
                    return (
                      <div
                        key={level}
                        className="mb-10"
                        data-ocid={`learn.${level.toLowerCase()}.section`}
                      >
                        {/* Section header */}
                        <div className="flex items-center gap-3 mb-5">
                          <div
                            className="w-8 h-8 rounded-xl flex items-center justify-center"
                            style={{
                              background: meta.bg,
                              border: `1px solid ${meta.border}`,
                            }}
                          >
                            {level === "Beginner" && (
                              <BookOpen
                                className="w-4 h-4"
                                style={{ color: meta.color }}
                              />
                            )}
                            {level === "Intermediate" && (
                              <TrendingUp
                                className="w-4 h-4"
                                style={{ color: meta.color }}
                              />
                            )}
                            {level === "Advanced" && (
                              <Brain
                                className="w-4 h-4"
                                style={{ color: meta.color }}
                              />
                            )}
                          </div>
                          <h2 className="text-lg font-display font-bold text-white">
                            {level}
                          </h2>
                          <span
                            className="text-xs font-accent uppercase px-2.5 py-0.5 rounded-full"
                            style={{
                              background: meta.bg,
                              color: meta.color,
                              border: `1px solid ${meta.border}`,
                            }}
                          >
                            {levelTopics.length} topics
                          </span>
                          <div
                            className="flex-1 h-px"
                            style={{
                              background: `linear-gradient(90deg, ${meta.border}, transparent)`,
                            }}
                          />
                        </div>

                        {/* Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                          {levelTopics.map((topic, i) => (
                            <TopicCard
                              key={topic.id}
                              topic={topic}
                              index={i}
                              onOpen={(t) => setSelectedTopic(t)}
                            />
                          ))}
                        </div>
                      </div>
                    );
                  },
                )
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* ── Topic Modal ── */}
      <Dialog.Root
        open={!!selectedTopic}
        onOpenChange={(open) => !open && setSelectedTopic(null)}
      >
        <AnimatePresence>
          {selectedTopic && (
            <TopicModal
              topic={selectedTopic}
              onClose={() => setSelectedTopic(null)}
            />
          )}
        </AnimatePresence>
      </Dialog.Root>
    </div>
  );
}
