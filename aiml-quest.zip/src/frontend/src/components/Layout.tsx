import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  Brain,
  Code2,
  FlaskConical,
  Gamepad2,
  Github,
  Home,
  Info,
  Linkedin,
  Mail,
  Menu,
  MessageSquare,
  Trophy,
  Twitter,
  X,
  Zap,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useEffect, useState } from "react";

const NAV_LINKS = [
  { label: "Home", to: "/", icon: Home },
  { label: "Learn", to: "/learn", icon: BookOpen },
  { label: "Practice", to: "/practice", icon: Code2 },
  { label: "Games", to: "/games", icon: Gamepad2 },
  { label: "Simulations", to: "/simulations", icon: FlaskConical },
  { label: "Quiz", to: "/quiz", icon: Trophy },
  { label: "Progress", to: "/progress", icon: BarChart3 },
  { label: "About", to: "/about", icon: Info },
];

const SOCIAL_LINKS = [
  {
    icon: Github,
    label: "GitHub",
    href: "https://github.com/aimlquest",
    color: "rgba(255,255,255,0.5)",
    hoverColor: "#fff",
  },
  {
    icon: Twitter,
    label: "Twitter / X",
    href: "https://twitter.com/aimlquest",
    color: "rgba(255,255,255,0.5)",
    hoverColor: "#22D3EE",
  },
  {
    icon: Linkedin,
    label: "LinkedIn",
    href: "https://linkedin.com/company/aimlquest",
    color: "rgba(255,255,255,0.5)",
    hoverColor: "#a78bfa",
  },
  {
    icon: MessageSquare,
    label: "Discord",
    href: "https://discord.gg/aimlquest",
    color: "rgba(255,255,255,0.5)",
    hoverColor: "#7C3AED",
  },
];

const RESOURCE_LINKS = [
  { label: "Documentation", href: "#" },
  { label: "Blog", href: "#" },
  { label: "Community", href: "#" },
  { label: "Newsletter", href: "#" },
];

export default function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const routerState = useRouterState();
  const pathname = routerState.location.pathname;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close mobile menu on route change
  const prevPathRef = { current: pathname };
  if (prevPathRef.current !== pathname) {
    setMobileOpen(false);
  }

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ backgroundColor: "#0B1026" }}
    >
      {/* ── Header ── */}
      <motion.header
        initial={{ y: -60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="sticky top-0 z-50"
        style={{
          background: scrolled
            ? "rgba(11, 16, 38, 0.92)"
            : "rgba(11, 16, 38, 0.75)",
          backdropFilter: "blur(16px)",
          WebkitBackdropFilter: "blur(16px)",
          borderBottom: scrolled
            ? "1px solid rgba(124, 58, 237, 0.3)"
            : "1px solid rgba(255,255,255,0.06)",
          boxShadow: scrolled
            ? "0 4px 24px rgba(0,0,0,0.4), 0 0 40px rgba(124,58,237,0.08)"
            : "none",
          transition: "all 0.3s cubic-bezier(0.4,0,0.2,1)",
        }}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center gap-2.5 group"
              data-ocid="nav.logo.link"
            >
              <div className="relative w-9 h-9 flex items-center justify-center">
                <div
                  className="absolute inset-0 rounded-lg"
                  style={{
                    background: "linear-gradient(135deg, #7C3AED, #22D3EE)",
                    opacity: 0.9,
                    boxShadow: "0 0 16px rgba(124,58,237,0.5)",
                  }}
                />
                <Brain className="relative z-10 text-white w-5 h-5" />
              </div>
              <span
                className="font-accent font-bold text-lg tracking-wider"
                style={{
                  background: "linear-gradient(135deg, #a78bfa, #22D3EE)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  textShadow: "none",
                }}
              >
                AIML
                <span
                  style={{ color: "#22D3EE", WebkitTextFillColor: "#22D3EE" }}
                >
                  Quest
                </span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav
              className="hidden md:flex items-center gap-0.5"
              aria-label="Main navigation"
            >
              {NAV_LINKS.map(({ label, to }) => {
                const active =
                  to === "/" ? pathname === "/" : pathname.startsWith(to);
                return (
                  <Link
                    key={to}
                    to={to}
                    className="relative px-2.5 py-2 text-xs font-medium rounded-lg transition-smooth group"
                    data-ocid={`nav.${label.toLowerCase()}.link`}
                    style={{
                      color: active ? "#22D3EE" : "rgba(255,255,255,0.7)",
                      background: active
                        ? "rgba(34,211,238,0.08)"
                        : "transparent",
                    }}
                  >
                    {active && (
                      <motion.div
                        layoutId="nav-indicator"
                        className="absolute inset-0 rounded-lg"
                        style={{
                          background: "rgba(34,211,238,0.1)",
                          border: "1px solid rgba(34,211,238,0.3)",
                        }}
                        transition={{ type: "spring", duration: 0.4 }}
                      />
                    )}
                    <span className="relative z-10">{label}</span>
                  </Link>
                );
              })}
              <div
                className="w-px h-5 mx-1"
                style={{ background: "rgba(255,255,255,0.1)" }}
              />
              <Link
                to="/learn"
                className="neon-btn-primary px-3 py-2 text-xs flex items-center gap-1.5"
                data-ocid="nav.start_learning.primary_button"
              >
                <Zap className="w-3 h-3" />
                Start
              </Link>
            </nav>

            {/* Mobile hamburger */}
            <button
              type="button"
              className="md:hidden w-10 h-10 flex items-center justify-center rounded-lg transition-smooth"
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
              }}
              onClick={() => setMobileOpen((v) => !v)}
              aria-label="Toggle navigation menu"
              aria-expanded={mobileOpen}
              data-ocid="nav.hamburger.toggle"
            >
              {mobileOpen ? (
                <X className="w-5 h-5 text-white" />
              ) : (
                <Menu className="w-5 h-5 text-white" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.25, ease: "easeInOut" }}
              className="md:hidden overflow-hidden"
              style={{
                background: "rgba(11, 16, 38, 0.97)",
                backdropFilter: "blur(16px)",
                borderTop: "1px solid rgba(124,58,237,0.2)",
              }}
              data-ocid="nav.mobile_menu"
            >
              <div className="container mx-auto px-4 py-4 flex flex-col gap-1">
                {NAV_LINKS.map(({ label, to, icon: Icon }) => {
                  const active =
                    to === "/" ? pathname === "/" : pathname.startsWith(to);
                  return (
                    <Link
                      key={to}
                      to={to}
                      className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-smooth"
                      data-ocid={`nav.mobile.${label.toLowerCase()}.link`}
                      style={{
                        color: active ? "#22D3EE" : "rgba(255,255,255,0.75)",
                        background: active
                          ? "rgba(34,211,238,0.08)"
                          : "transparent",
                        border: active
                          ? "1px solid rgba(34,211,238,0.2)"
                          : "1px solid transparent",
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      {label}
                    </Link>
                  );
                })}
                <div
                  className="pt-2 mt-1 border-t"
                  style={{ borderColor: "rgba(255,255,255,0.08)" }}
                >
                  <Link
                    to="/learn"
                    className="neon-btn-primary w-full justify-center gap-2"
                    data-ocid="nav.mobile.start_learning.primary_button"
                  >
                    <Zap className="w-4 h-4" />
                    Start Learning
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>

      {/* ── Main content ── */}
      <main className="flex-1 relative">
        <Outlet />
      </main>

      {/* ── Footer ── */}
      <footer
        className="relative z-10 mt-auto"
        style={{
          background: "rgba(9, 13, 32, 0.98)",
          backdropFilter: "blur(16px)",
          WebkitBackdropFilter: "blur(16px)",
          borderTop: "1px solid rgba(124,58,237,0.25)",
          boxShadow:
            "0 -4px 40px rgba(124,58,237,0.06), 0 -1px 0 rgba(34,211,238,0.06)",
        }}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-6">
          {/* 4-column grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            {/* Col 1 — Brand */}
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2.5 mb-4">
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{
                    background: "linear-gradient(135deg, #7C3AED, #22D3EE)",
                    boxShadow: "0 0 16px rgba(124,58,237,0.4)",
                  }}
                >
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <span
                  className="font-accent font-bold text-base tracking-wider"
                  style={{
                    background: "linear-gradient(135deg, #a78bfa, #22D3EE)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  AIML Quest
                </span>
              </div>
              <p
                className="text-sm leading-relaxed mb-6"
                style={{ color: "rgba(255,255,255,0.45)" }}
              >
                Learn AI the Fun Way — interactive lessons, mini-games, coding
                playgrounds, and real-world simulations.
              </p>

              {/* Social icons */}
              <div className="flex items-center gap-3">
                {SOCIAL_LINKS.map(({ icon: Icon, label, href, hoverColor }) => (
                  <a
                    key={label}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={label}
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-smooth group"
                    style={{
                      background: "rgba(255,255,255,0.05)",
                      border: "1px solid rgba(255,255,255,0.08)",
                    }}
                    onMouseEnter={(e) => {
                      (
                        e.currentTarget.querySelector(
                          "svg",
                        ) as SVGElement | null
                      )?.style.setProperty("color", hoverColor);
                      e.currentTarget.style.borderColor = `${hoverColor}50`;
                      e.currentTarget.style.background = `${hoverColor}12`;
                    }}
                    onMouseLeave={(e) => {
                      (
                        e.currentTarget.querySelector(
                          "svg",
                        ) as SVGElement | null
                      )?.style.setProperty("color", "rgba(255,255,255,0.45)");
                      e.currentTarget.style.borderColor =
                        "rgba(255,255,255,0.08)";
                      e.currentTarget.style.background =
                        "rgba(255,255,255,0.05)";
                    }}
                    data-ocid={`footer.social.${label.toLowerCase().replace(/[^a-z0-9]/g, "_")}.link`}
                  >
                    <Icon
                      className="w-4 h-4 transition-smooth"
                      style={{ color: "rgba(255,255,255,0.45)" }}
                    />
                  </a>
                ))}
              </div>
            </div>

            {/* Col 2 — Quick Links */}
            <div>
              <h4
                className="font-display font-semibold text-xs uppercase tracking-widest mb-5"
                style={{ color: "#22D3EE" }}
              >
                Quick Links
              </h4>
              <ul className="flex flex-col gap-2.5">
                {NAV_LINKS.map(({ label, to }) => (
                  <li key={to}>
                    <Link
                      to={to}
                      className="text-sm transition-smooth hover:text-white"
                      style={{ color: "rgba(255,255,255,0.5)" }}
                      data-ocid={`footer.quicklinks.${label.toLowerCase()}.link`}
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Col 3 — Resources */}
            <div>
              <h4
                className="font-display font-semibold text-xs uppercase tracking-widest mb-5"
                style={{ color: "#7C3AED" }}
              >
                Resources
              </h4>
              <ul className="flex flex-col gap-2.5">
                {RESOURCE_LINKS.map(({ label, href }) => (
                  <li key={label}>
                    <a
                      href={href}
                      className="text-sm transition-smooth hover:text-white"
                      style={{ color: "rgba(255,255,255,0.5)" }}
                      data-ocid={`footer.resources.${label.toLowerCase()}.link`}
                    >
                      {label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Col 4 — Contact */}
            <div>
              <h4
                className="font-display font-semibold text-xs uppercase tracking-widest mb-5"
                style={{ color: "#a78bfa" }}
              >
                Contact
              </h4>
              <ul className="flex flex-col gap-3">
                <li>
                  <a
                    href="mailto:contact@aimlquest.com"
                    className="flex items-center gap-2 text-sm transition-smooth hover:text-white group"
                    style={{ color: "rgba(255,255,255,0.5)" }}
                    data-ocid="footer.contact.email.link"
                  >
                    <Mail
                      className="w-3.5 h-3.5 flex-shrink-0"
                      style={{ color: "rgba(124,58,237,0.7)" }}
                    />
                    contact@aimlquest.com
                  </a>
                </li>
                <li>
                  <a
                    href="https://discord.gg/aimlquest"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm transition-smooth hover:text-white"
                    style={{ color: "rgba(255,255,255,0.5)" }}
                    data-ocid="footer.contact.discord.link"
                  >
                    <MessageSquare
                      className="w-3.5 h-3.5 flex-shrink-0"
                      style={{ color: "rgba(34,211,238,0.7)" }}
                    />
                    Discord Community
                  </a>
                </li>
                <li>
                  <a
                    href="https://github.com/aimlquest"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm transition-smooth hover:text-white"
                    style={{ color: "rgba(255,255,255,0.5)" }}
                    data-ocid="footer.contact.github.link"
                  >
                    <Github
                      className="w-3.5 h-3.5 flex-shrink-0"
                      style={{ color: "rgba(255,255,255,0.5)" }}
                    />
                    GitHub
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom bar */}
          <div
            className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs"
            style={{
              borderTop: "1px solid rgba(255,255,255,0.06)",
              color: "rgba(255,255,255,0.3)",
            }}
          >
            <span>
              © {new Date().getFullYear()} AIML Quest. All rights reserved. |
              Built with ❤️ for AI enthusiasts
            </span>
            <span>
              Built with love using{" "}
              <a
                href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="transition-smooth hover:text-white"
                style={{ color: "rgba(124,58,237,0.7)" }}
              >
                caffeine.ai
              </a>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
