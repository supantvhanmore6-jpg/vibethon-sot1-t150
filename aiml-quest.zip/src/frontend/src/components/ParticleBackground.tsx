import { useMemo } from "react";

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  color: string;
  duration: number;
  delay: number;
  opacity: number;
}

const PARTICLE_COUNT = 60;

export default function ParticleBackground() {
  const particles = useMemo<Particle[]>(() => {
    const colors = [
      "rgba(124, 58, 237, 0.7)",
      "rgba(34, 211, 238, 0.7)",
      "rgba(167, 139, 250, 0.5)",
      "rgba(103, 232, 249, 0.5)",
      "rgba(255, 255, 255, 0.4)",
    ];
    return Array.from({ length: PARTICLE_COUNT }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      color: colors[Math.floor(Math.random() * colors.length)],
      duration: Math.random() * 12 + 6,
      delay: Math.random() * -15,
      opacity: Math.random() * 0.6 + 0.2,
    }));
  }, []);

  return (
    <div
      className="fixed inset-0 pointer-events-none overflow-hidden"
      style={{ zIndex: 0 }}
      aria-hidden="true"
    >
      {/* Grid pattern overlay */}
      <div
        className="absolute inset-0 grid-pattern opacity-40"
        style={{ zIndex: 1 }}
      />

      {/* Radial glow centers */}
      <div
        className="absolute rounded-full"
        style={{
          width: 600,
          height: 600,
          top: "10%",
          left: "10%",
          background:
            "radial-gradient(circle, rgba(124,58,237,0.12) 0%, transparent 70%)",
          zIndex: 2,
        }}
      />
      <div
        className="absolute rounded-full"
        style={{
          width: 500,
          height: 500,
          bottom: "15%",
          right: "10%",
          background:
            "radial-gradient(circle, rgba(34,211,238,0.08) 0%, transparent 70%)",
          zIndex: 2,
        }}
      />
      <div
        className="absolute rounded-full"
        style={{
          width: 400,
          height: 400,
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          background:
            "radial-gradient(circle, rgba(124,58,237,0.06) 0%, transparent 70%)",
          zIndex: 2,
        }}
      />

      {/* Floating particles */}
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            opacity: p.opacity,
            zIndex: 3,
            animation: `particle-drift ${p.duration}s ease-in-out ${p.delay}s infinite`,
            boxShadow: p.size > 2.5 ? `0 0 ${p.size * 3}px ${p.color}` : "none",
          }}
        />
      ))}

      {/* Horizontal scan line effect */}
      <div
        className="absolute left-0 right-0 h-px"
        style={{
          background:
            "linear-gradient(90deg, transparent, rgba(34,211,238,0.15), rgba(124,58,237,0.2), rgba(34,211,238,0.15), transparent)",
          top: "30%",
          zIndex: 3,
          animation: "particle-drift 10s ease-in-out infinite",
        }}
      />
    </div>
  );
}
