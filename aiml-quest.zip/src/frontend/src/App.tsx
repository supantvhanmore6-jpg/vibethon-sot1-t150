import {
  RouterProvider,
  createRootRoute,
  createRoute,
  createRouter,
} from "@tanstack/react-router";
import Layout from "./components/Layout";
import About from "./pages/About";
import Home from "./pages/Home";
import Learn from "./pages/Learn";
import MiniGames from "./pages/MiniGames";
import Practice from "./pages/Practice";
import ProgressTracker from "./pages/ProgressTracker";
import QuizArena from "./pages/QuizArena";
import Simulations from "./pages/Simulations";

const rootRoute = createRootRoute({
  component: Layout,
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/",
  component: Home,
});

const learnRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/learn",
  component: Learn,
});

const practiceRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/practice",
  component: Practice,
});

const aboutRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/about",
  component: About,
});

const simulationsRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/simulations",
  component: Simulations,
});

const miniGamesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/games",
  component: MiniGames,
});

const quizArenaRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/quiz",
  component: QuizArena,
});

const progressRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: "/progress",
  component: ProgressTracker,
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  learnRoute,
  practiceRoute,
  aboutRoute,
  simulationsRoute,
  miniGamesRoute,
  quizArenaRoute,
  progressRoute,
]);

const router = createRouter({ routeTree });

declare module "@tanstack/react-router" {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
