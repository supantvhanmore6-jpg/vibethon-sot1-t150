import typography from "@tailwindcss/typography";
import containerQueries from "@tailwindcss/container-queries";
import animate from "tailwindcss-animate";

/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: ["index.html", "src/**/*.{js,ts,jsx,tsx,html,css}"],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "oklch(var(--border))",
        input: "oklch(var(--input))",
        ring: "oklch(var(--ring) / <alpha-value>)",
        background: "oklch(var(--background))",
        foreground: "oklch(var(--foreground))",
        primary: {
          DEFAULT: "oklch(var(--primary) / <alpha-value>)",
          foreground: "oklch(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "oklch(var(--secondary) / <alpha-value>)",
          foreground: "oklch(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "oklch(var(--destructive) / <alpha-value>)",
          foreground: "oklch(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "oklch(var(--muted) / <alpha-value>)",
          foreground: "oklch(var(--muted-foreground) / <alpha-value>)",
        },
        accent: {
          DEFAULT: "oklch(var(--accent) / <alpha-value>)",
          foreground: "oklch(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "oklch(var(--popover))",
          foreground: "oklch(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "oklch(var(--card))",
          foreground: "oklch(var(--card-foreground))",
        },
        chart: {
          1: "oklch(var(--chart-1))",
          2: "oklch(var(--chart-2))",
          3: "oklch(var(--chart-3))",
          4: "oklch(var(--chart-4))",
          5: "oklch(var(--chart-5))",
        },
        sidebar: {
          DEFAULT: "oklch(var(--sidebar))",
          foreground: "oklch(var(--sidebar-foreground))",
          primary: "oklch(var(--sidebar-primary))",
          "primary-foreground": "oklch(var(--sidebar-primary-foreground))",
          accent: "oklch(var(--sidebar-accent))",
          "accent-foreground": "oklch(var(--sidebar-accent-foreground))",
          border: "oklch(var(--sidebar-border))",
          ring: "oklch(var(--sidebar-ring))",
        },
        /* AIML Quest brand tokens — raw hex for direct use */
        "aiml-bg":      "#0B1026",
        "aiml-purple":  "#7C3AED",
        "aiml-cyan":    "#22D3EE",
        "aiml-card":    "rgba(255,255,255,0.04)",
      },
      fontFamily: {
        display: ["Poppins", "var(--font-display)", "sans-serif"],
        body:    ["Inter",   "var(--font-body)",    "sans-serif"],
        accent:  ["Orbitron","var(--font-accent)",  "sans-serif"],
        mono:    ["var(--font-mono)", "monospace"],
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        "2xl": "16px",
        "3xl": "20px",
      },
      boxShadow: {
        xs: "0 1px 2px 0 rgba(0,0,0,0.05)",
        subtle: "0 1px 3px rgba(0,0,0,0.2)",
        /* Neon purple glows */
        glow:    "0 0 20px rgba(124, 58, 237, 0.35)",
        "glow-md": "0 0 32px rgba(124, 58, 237, 0.5)",
        "glow-lg": "0 0 50px rgba(124, 58, 237, 0.6)",
        /* Neon cyan glows */
        "glow-cyan":    "0 0 20px rgba(34, 211, 238, 0.35)",
        "glow-cyan-md": "0 0 32px rgba(34, 211, 238, 0.5)",
        "glow-cyan-lg": "0 0 50px rgba(34, 211, 238, 0.6)",
        /* Card glow */
        "card-glow": "0 0 30px rgba(124, 58, 237, 0.15), 0 8px 24px rgba(0,0,0,0.4)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "slide-in-up": {
          from: { opacity: "0", transform: "translateY(24px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "slide-in-down": {
          from: { opacity: "0", transform: "translateY(-24px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "slide-in-left": {
          from: { opacity: "0", transform: "translateX(-24px)" },
          to: { opacity: "1", transform: "translateX(0)" },
        },
        "pulse-glow": {
          "0%, 100%": { opacity: "1", filter: "drop-shadow(0 0 10px rgba(124, 58, 237, 0.4))" },
          "50%": { opacity: "0.8", filter: "drop-shadow(0 0 24px rgba(124, 58, 237, 0.7))" },
        },
        "border-pulse": {
          "0%, 100%": { "border-color": "rgba(124, 58, 237, 0.3)" },
          "50%": { "border-color": "rgba(34, 211, 238, 0.6)" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.35s ease-out",
        "slide-in-up": "slide-in-up 0.45s ease-out",
        "slide-in-down": "slide-in-down 0.45s ease-out",
        "slide-in-left": "slide-in-left 0.45s ease-out",
        "pulse-glow": "pulse-glow 2.5s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "border-pulse": "border-pulse 3s ease-in-out infinite",
      },
    },
  },
  plugins: [typography, containerQueries, animate],
};
