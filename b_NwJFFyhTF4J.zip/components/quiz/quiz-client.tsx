"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { CheckCircle2, XCircle, Trophy, ArrowRight, RotateCcw } from "lucide-react"
import { cn } from "@/lib/utils"

interface Quiz {
  id: string
  title: string
  description: string
  passing_score: number
  xp_reward: number
}

interface Question {
  id: string
  question: string
  options: string[]
  correct_answer: number
  explanation: string
}

interface QuizClientProps {
  quiz: Quiz
  questions: Question[]
  moduleId: string
  moduleName: string
}

type QuizState = "intro" | "questions" | "results"

export function QuizClient({ quiz, questions, moduleId, moduleName }: QuizClientProps) {
  const [state, setState] = useState<QuizState>("intro")
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([])
  const [showExplanation, setShowExplanation] = useState(false)
  const [score, setScore] = useState(0)
  const [saving, setSaving] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const question = questions[currentQuestion]
  const options = typeof question?.options === "string" 
    ? JSON.parse(question.options) 
    : question?.options || []
  const isLastQuestion = currentQuestion === questions.length - 1
  const progress = ((currentQuestion + 1) / questions.length) * 100

  const handleStartQuiz = () => {
    setState("questions")
    setSelectedAnswers([])
    setCurrentQuestion(0)
    setScore(0)
  }

  const handleSelectAnswer = (answerIndex: number) => {
    if (showExplanation) return
    
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestion] = answerIndex
    setSelectedAnswers(newAnswers)
    
    if (answerIndex === question.correct_answer) {
      setScore(score + 1)
    }
    
    setShowExplanation(true)
  }

  const handleNextQuestion = async () => {
    setShowExplanation(false)
    
    if (isLastQuestion) {
      await saveQuizResult()
      setState("results")
    } else {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const saveQuizResult = async () => {
    setSaving(true)
    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      const passed = (score / questions.length) * 100 >= quiz.passing_score

      // Save quiz attempt
      await supabase.from("quiz_attempts").insert({
        user_id: user.id,
        quiz_id: quiz.id,
        score: score,
        total_questions: questions.length,
        passed: passed,
        answers: selectedAnswers,
      })

      // Award XP if passed
      if (passed) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("xp_points, level")
          .eq("id", user.id)
          .single()

        if (profile) {
          const newXp = (profile.xp_points || 0) + quiz.xp_reward
          const newLevel = Math.floor(newXp / 100) + 1

          await supabase
            .from("profiles")
            .update({ xp_points: newXp, level: newLevel })
            .eq("id", user.id)
        }

        // Check for Quiz Master badge
        const { data: badge } = await supabase
          .from("badges")
          .select("id")
          .eq("requirement_type", "quizzes_passed")
          .eq("requirement_value", 1)
          .single()

        if (badge) {
          await supabase.from("user_badges").upsert({
            user_id: user.id,
            badge_id: badge.id,
          }, {
            onConflict: "user_id,badge_id"
          })
        }

        // Check for Perfect Score badge
        if (score === questions.length) {
          const { data: perfectBadge } = await supabase
            .from("badges")
            .select("id")
            .eq("requirement_type", "perfect_quiz")
            .single()

          if (perfectBadge) {
            await supabase.from("user_badges").upsert({
              user_id: user.id,
              badge_id: perfectBadge.id,
            }, {
              onConflict: "user_id,badge_id"
            })
          }
        }
      }
    } catch (error) {
      console.error("Error saving quiz result:", error)
    } finally {
      setSaving(false)
    }
  }

  const percentageScore = Math.round((score / questions.length) * 100)
  const passed = percentageScore >= quiz.passing_score

  if (state === "intro") {
    return (
      <Card>
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl">{quiz.title}</CardTitle>
          <CardDescription>{quiz.description}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-2xl font-bold text-foreground">{questions.length}</p>
              <p className="text-sm text-muted-foreground">Questions</p>
            </div>
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-2xl font-bold text-foreground">{quiz.passing_score}%</p>
              <p className="text-sm text-muted-foreground">To Pass</p>
            </div>
          </div>
          <div className="p-4 rounded-lg bg-primary/5 text-center">
            <p className="text-sm text-muted-foreground">Reward</p>
            <p className="text-xl font-bold text-primary">+{quiz.xp_reward} XP</p>
          </div>
          <Button onClick={handleStartQuiz} className="w-full" size="lg">
            Start Quiz
          </Button>
        </CardContent>
      </Card>
    )
  }

  if (state === "results") {
    return (
      <Card>
        <CardHeader className="text-center">
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
            passed ? "bg-primary/10" : "bg-destructive/10"
          }`}>
            {passed ? (
              <Trophy className="w-8 h-8 text-primary" />
            ) : (
              <XCircle className="w-8 h-8 text-destructive" />
            )}
          </div>
          <CardTitle className="text-2xl">
            {passed ? "Congratulations!" : "Keep Learning!"}
          </CardTitle>
          <CardDescription>
            {passed 
              ? `You passed the quiz and earned ${quiz.xp_reward} XP!`
              : `You need ${quiz.passing_score}% to pass. Review the lessons and try again.`
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <p className="text-5xl font-bold text-foreground mb-2">{percentageScore}%</p>
            <p className="text-muted-foreground">
              {score} of {questions.length} correct
            </p>
          </div>
          <div className="flex gap-3">
            {!passed && (
              <Button onClick={handleStartQuiz} variant="outline" className="flex-1">
                <RotateCcw className="w-4 h-4 mr-2" />
                Try Again
              </Button>
            )}
            <Button 
              onClick={() => {
                router.push(`/modules/${moduleId}`)
                router.refresh()
              }} 
              className="flex-1"
            >
              Back to Module
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Progress */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-muted-foreground">
            Question {currentQuestion + 1} of {questions.length}
          </span>
          <span className="text-sm font-medium text-foreground">{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{question.question}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {options.map((option: string, index: number) => {
            const isSelected = selectedAnswers[currentQuestion] === index
            const isCorrect = index === question.correct_answer
            const showResult = showExplanation

            return (
              <button
                key={index}
                onClick={() => handleSelectAnswer(index)}
                disabled={showExplanation}
                className={cn(
                  "w-full p-4 rounded-lg border text-left transition-all",
                  "hover:border-primary/50 hover:bg-primary/5",
                  isSelected && !showResult && "border-primary bg-primary/5",
                  showResult && isCorrect && "border-primary bg-primary/10",
                  showResult && isSelected && !isCorrect && "border-destructive bg-destructive/10",
                  showExplanation && !isSelected && !isCorrect && "opacity-50"
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-foreground">{option}</span>
                  {showResult && isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-primary" />
                  )}
                  {showResult && isSelected && !isCorrect && (
                    <XCircle className="w-5 h-5 text-destructive" />
                  )}
                </div>
              </button>
            )
          })}
        </CardContent>
      </Card>

      {/* Explanation */}
      {showExplanation && (
        <Card className="border-primary/50 bg-primary/5">
          <CardContent className="p-4">
            <p className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">Explanation: </span>
              {question.explanation}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Next Button */}
      {showExplanation && (
        <Button onClick={handleNextQuestion} className="w-full" disabled={saving}>
          {isLastQuestion ? "See Results" : "Next Question"}
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      )}
    </div>
  )
}
