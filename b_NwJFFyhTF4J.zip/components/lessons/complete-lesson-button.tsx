"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Loader2 } from "lucide-react"

interface CompleteLessonButtonProps {
  lessonId: string
  xpReward: number
  nextLessonUrl: string
}

export function CompleteLessonButton({ lessonId, xpReward, nextLessonUrl }: CompleteLessonButtonProps) {
  const [loading, setLoading] = useState(false)
  const [completed, setCompleted] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleComplete = async () => {
    setLoading(true)

    try {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return

      // Mark lesson as completed
      await supabase.from("user_progress").upsert({
        user_id: user.id,
        lesson_id: lessonId,
        completed: true,
        completed_at: new Date().toISOString(),
      }, {
        onConflict: "user_id,lesson_id"
      })

      // Update XP
      const { data: profile } = await supabase
        .from("profiles")
        .select("xp_points, level")
        .eq("id", user.id)
        .single()

      if (profile) {
        const newXp = (profile.xp_points || 0) + xpReward
        const newLevel = Math.floor(newXp / 100) + 1

        await supabase
          .from("profiles")
          .update({ 
            xp_points: newXp, 
            level: newLevel,
            last_activity_date: new Date().toISOString().split('T')[0]
          })
          .eq("id", user.id)
      }

      // Check for badge eligibility
      const { data: completedCount } = await supabase
        .from("user_progress")
        .select("id", { count: "exact" })
        .eq("user_id", user.id)
        .eq("completed", true)

      const totalCompleted = (completedCount as unknown as number) || 1

      // Award badges based on lessons completed
      const badgeThresholds = [
        { lessons: 1, type: "lessons_completed" },
        { lessons: 5, type: "lessons_completed" },
        { lessons: 10, type: "lessons_completed" },
      ]

      for (const threshold of badgeThresholds) {
        if (totalCompleted >= threshold.lessons) {
          const { data: badge } = await supabase
            .from("badges")
            .select("id")
            .eq("requirement_type", threshold.type)
            .eq("requirement_value", threshold.lessons)
            .single()

          if (badge) {
            await supabase.from("user_badges").upsert({
              user_id: user.id,
              badge_id: badge.id,
            }, {
              onConflict: "user_id,badge_id"
            })
          }
        }
      }

      setCompleted(true)
      
      // Navigate after a brief delay
      setTimeout(() => {
        router.push(nextLessonUrl)
        router.refresh()
      }, 1000)

    } catch (error) {
      console.error("Error completing lesson:", error)
    } finally {
      setLoading(false)
    }
  }

  if (completed) {
    return (
      <Button disabled className="bg-primary/10 text-primary">
        <CheckCircle2 className="w-4 h-4 mr-2" />
        Completed! +{xpReward} XP
      </Button>
    )
  }

  return (
    <Button onClick={handleComplete} disabled={loading}>
      {loading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Completing...
        </>
      ) : (
        <>
          <CheckCircle2 className="w-4 h-4 mr-2" />
          Mark as Complete
        </>
      )}
    </Button>
  )
}
