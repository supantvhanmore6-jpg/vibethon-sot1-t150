-- AIML Learning Platform Database Schema

-- User profiles table (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  avatar_url text,
  xp_points integer default 0,
  level integer default 1,
  streak_days integer default 0,
  last_activity_date date,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

create policy "profiles_select_own" on public.profiles for select using (auth.uid() = id);
create policy "profiles_insert_own" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id);

-- Learning modules table
create table if not exists public.modules (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  difficulty text check (difficulty in ('beginner', 'intermediate', 'advanced')),
  order_index integer not null,
  icon text,
  estimated_minutes integer default 30,
  created_at timestamp with time zone default now()
);

alter table public.modules enable row level security;
create policy "modules_select_all" on public.modules for select using (true);

-- Lessons table
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references public.modules(id) on delete cascade,
  title text not null,
  content text not null,
  order_index integer not null,
  xp_reward integer default 10,
  created_at timestamp with time zone default now()
);

alter table public.lessons enable row level security;
create policy "lessons_select_all" on public.lessons for select using (true);

-- User progress table
create table if not exists public.user_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  lesson_id uuid references public.lessons(id) on delete cascade,
  completed boolean default false,
  completed_at timestamp with time zone,
  created_at timestamp with time zone default now(),
  unique(user_id, lesson_id)
);

alter table public.user_progress enable row level security;
create policy "progress_select_own" on public.user_progress for select using (auth.uid() = user_id);
create policy "progress_insert_own" on public.user_progress for insert with check (auth.uid() = user_id);
create policy "progress_update_own" on public.user_progress for update using (auth.uid() = user_id);

-- Quizzes table
create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  module_id uuid references public.modules(id) on delete cascade,
  title text not null,
  description text,
  passing_score integer default 70,
  xp_reward integer default 50,
  created_at timestamp with time zone default now()
);

alter table public.quizzes enable row level security;
create policy "quizzes_select_all" on public.quizzes for select using (true);

-- Quiz questions table
create table if not exists public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid references public.quizzes(id) on delete cascade,
  question text not null,
  options jsonb not null, -- Array of options
  correct_answer integer not null, -- Index of correct option
  explanation text,
  order_index integer not null,
  created_at timestamp with time zone default now()
);

alter table public.quiz_questions enable row level security;
create policy "questions_select_all" on public.quiz_questions for select using (true);

-- Quiz attempts table
create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  quiz_id uuid references public.quizzes(id) on delete cascade,
  score integer not null,
  total_questions integer not null,
  passed boolean not null,
  answers jsonb, -- User's answers
  completed_at timestamp with time zone default now()
);

alter table public.quiz_attempts enable row level security;
create policy "attempts_select_own" on public.quiz_attempts for select using (auth.uid() = user_id);
create policy "attempts_insert_own" on public.quiz_attempts for insert with check (auth.uid() = user_id);

-- Badges table
create table if not exists public.badges (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  icon text not null,
  requirement_type text not null, -- 'xp', 'modules', 'quizzes', 'streak'
  requirement_value integer not null,
  created_at timestamp with time zone default now()
);

alter table public.badges enable row level security;
create policy "badges_select_all" on public.badges for select using (true);

-- User badges table
create table if not exists public.user_badges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  badge_id uuid references public.badges(id) on delete cascade,
  earned_at timestamp with time zone default now(),
  unique(user_id, badge_id)
);

alter table public.user_badges enable row level security;
create policy "user_badges_select_own" on public.user_badges for select using (auth.uid() = user_id);
create policy "user_badges_insert_own" on public.user_badges for insert with check (auth.uid() = user_id);

-- Code playground submissions
create table if not exists public.code_submissions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  title text,
  code text not null,
  language text default 'python',
  output text,
  created_at timestamp with time zone default now()
);

alter table public.code_submissions enable row level security;
create policy "submissions_select_own" on public.code_submissions for select using (auth.uid() = user_id);
create policy "submissions_insert_own" on public.code_submissions for insert with check (auth.uid() = user_id);

-- Trigger to auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
