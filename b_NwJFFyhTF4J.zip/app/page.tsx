import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Brain, BookOpen, Trophy, Code, Zap, Users, ArrowRight, CheckCircle2 } from "lucide-react"

const features = [
  {
    icon: BookOpen,
    title: "Structured Learning",
    description: "Progress through carefully crafted modules from AI basics to advanced deep learning concepts.",
  },
  {
    icon: Code,
    title: "Hands-on Coding",
    description: "Practice with an interactive Python playground to experiment with ML algorithms.",
  },
  {
    icon: Trophy,
    title: "Gamified Progress",
    description: "Earn XP, unlock badges, and compete on leaderboards as you master new concepts.",
  },
  {
    icon: Zap,
    title: "Interactive Quizzes",
    description: "Test your knowledge with quizzes and get instant feedback on your understanding.",
  },
]

const modules = [
  { title: "Introduction to AI", lessons: 3, difficulty: "Beginner" },
  { title: "Machine Learning Basics", lessons: 3, difficulty: "Beginner" },
  { title: "Neural Networks", lessons: 4, difficulty: "Intermediate" },
  { title: "Deep Learning", lessons: 5, difficulty: "Advanced" },
]

export default async function HomePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (user) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-foreground">LearnAI</span>
            </div>
            <div className="flex items-center gap-3">
              <Button asChild variant="ghost">
                <Link href="/auth/login">Sign in</Link>
              </Button>
              <Button asChild>
                <Link href="/auth/sign-up">Get Started</Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
            <Zap className="w-4 h-4" />
            Start learning AI today
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
            Master AI & Machine Learning
            <span className="text-primary"> Step by Step</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            Interactive lessons, hands-on coding exercises, and gamified learning to take you from beginner to AI expert.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button asChild size="lg" className="text-base px-8">
              <Link href="/auth/sign-up">
                Start Learning Free
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-base px-8">
              <Link href="/auth/login">Sign in</Link>
            </Button>
          </div>
          <div className="flex items-center justify-center gap-6 mt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Free to start
            </div>
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              1000+ learners
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Everything you need to learn AI
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our platform combines theory with practice to give you a comprehensive understanding of AI and ML.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <Card key={feature.title} className="bg-card border-border">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Curriculum Preview */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Structured curriculum
            </h2>
            <p className="text-muted-foreground">
              Progress through modules designed to build your knowledge step by step.
            </p>
          </div>
          <div className="space-y-4">
            {modules.map((module, index) => (
              <Card key={module.title} className="bg-card border-border">
                <CardContent className="flex items-center justify-between p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">{module.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {module.lessons} lessons
                      </p>
                    </div>
                  </div>
                  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                    module.difficulty === "Beginner" 
                      ? "bg-primary/10 text-primary"
                      : module.difficulty === "Intermediate"
                      ? "bg-accent/10 text-accent-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {module.difficulty}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary/5">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Ready to start your AI journey?
          </h2>
          <p className="text-muted-foreground mb-8">
            Join thousands of learners who are mastering AI and ML with our interactive platform.
          </p>
          <Button asChild size="lg" className="text-base px-8">
            <Link href="/auth/sign-up">
              Create Free Account
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Brain className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-foreground">LearnAI</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Built with Next.js and Supabase
          </p>
        </div>
      </footer>
    </div>
  )
}
