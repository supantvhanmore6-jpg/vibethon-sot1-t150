import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import Link from "next/link"
import { 
  Brain, 
  BookOpen, 
  Trophy, 
  Zap, 
  Target, 
  Flame, 
  ArrowRight,
  CheckCircle2,
  Clock
} from "lucide-react"

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [
    { data: profile },
    { data: modules },
    { data: userProgress },
    { data: userBadges },
    { data: allBadges },
  ] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user!.id).single(),
    supabase.from("modules").select("*, lessons(count)").order("order_index"),
    supabase.from("user_progress").select("*, lessons(*)").eq("user_id", user!.id),
    supabase.from("user_badges").select("*, badges(*)").eq("user_id", user!.id),
    supabase.from("badges").select("*"),
  ])

  const completedLessons = userProgress?.filter(p => p.completed).length || 0
  const totalLessons = modules?.reduce((acc, m) => acc + (m.lessons?.[0]?.count || 0), 0) || 0
  const progressPercentage = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0

  // Find next lesson to continue
  const completedLessonIds = new Set(userProgress?.filter(p => p.completed).map(p => p.lesson_id) || [])
  let nextLesson = null
  let nextModule = null

  for (const module of modules || []) {
    const { data: lessons } = await supabase
      .from("lessons")
      .select("*")
      .eq("module_id", module.id)
      .order("order_index")

    for (const lesson of lessons || []) {
      if (!completedLessonIds.has(lesson.id)) {
        nextLesson = lesson
        nextModule = module
        break
      }
    }
    if (nextLesson) break
  }

  const earnedBadgeIds = new Set(userBadges?.map(ub => ub.badge_id) || [])
  const recentBadges = userBadges?.slice(0, 3) || []

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">
          Welcome back, {profile?.display_name || "Learner"}!
        </h1>
        <p className="text-muted-foreground">
          Continue your journey to master AI and Machine Learning.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{profile?.xp_points || 0}</p>
              <p className="text-sm text-muted-foreground">Total XP</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <Target className="w-5 h-5 text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">Level {profile?.level || 1}</p>
              <p className="text-sm text-muted-foreground">Current Level</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Flame className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{profile?.streak_days || 0}</p>
              <p className="text-sm text-muted-foreground">Day Streak</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-accent-foreground" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{userBadges?.length || 0}</p>
              <p className="text-sm text-muted-foreground">Badges Earned</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Continue Learning */}
          {nextLesson && nextModule && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-primary" />
                  Continue Learning
                </CardTitle>
                <CardDescription>Pick up where you left off</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div>
                    <p className="text-sm text-muted-foreground">{nextModule.title}</p>
                    <p className="font-medium text-foreground">{nextLesson.title}</p>
                    <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>~5 min read</span>
                      <span className="text-primary">+{nextLesson.xp_reward} XP</span>
                    </div>
                  </div>
                  <Button asChild>
                    <Link href={`/modules/${nextModule.id}/lessons/${nextLesson.id}`}>
                      Continue
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Overall Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Your Progress
              </CardTitle>
              <CardDescription>
                {completedLessons} of {totalLessons} lessons completed
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-muted-foreground">Overall Progress</span>
                    <span className="text-sm font-medium text-foreground">{progressPercentage}%</span>
                  </div>
                  <Progress value={progressPercentage} className="h-2" />
                </div>

                <div className="grid gap-3">
                  {modules?.slice(0, 3).map((module) => {
                    const moduleProgress = userProgress?.filter(
                      p => p.completed && p.lessons?.module_id === module.id
                    ).length || 0
                    const moduleTotalLessons = module.lessons?.[0]?.count || 0
                    const modulePercent = moduleTotalLessons > 0 
                      ? Math.round((moduleProgress / moduleTotalLessons) * 100) 
                      : 0

                    return (
                      <Link
                        key={module.id}
                        href={`/modules/${module.id}`}
                        className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          {modulePercent === 100 ? (
                            <CheckCircle2 className="w-5 h-5 text-primary" />
                          ) : (
                            <div className="w-5 h-5 rounded-full border-2 border-muted" />
                          )}
                          <span className="font-medium text-foreground">{module.title}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {moduleProgress}/{moduleTotalLessons}
                        </span>
                      </Link>
                    )
                  })}
                </div>

                <Button asChild variant="outline" className="w-full">
                  <Link href="/modules">
                    View All Modules
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Badges */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-primary" />
                Badges
              </CardTitle>
              <CardDescription>
                {userBadges?.length || 0} of {allBadges?.length || 0} earned
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recentBadges.length > 0 ? (
                <div className="space-y-3">
                  {recentBadges.map((ub) => (
                    <div key={ub.id} className="flex items-center gap-3 p-2 rounded-lg bg-muted/50">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Trophy className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground text-sm">{ub.badges?.name}</p>
                        <p className="text-xs text-muted-foreground">{ub.badges?.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Complete lessons to earn badges!
                </p>
              )}
              <Button asChild variant="ghost" className="w-full mt-3">
                <Link href="/profile">View All Badges</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button asChild variant="outline" className="w-full justify-start">
                <Link href="/playground">
                  <Brain className="w-4 h-4 mr-2" />
                  Code Playground
                </Link>
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link href="/ai-demo">
                  <Zap className="w-4 h-4 mr-2" />
                  Try AI Demo
                </Link>
              </Button>
              <Button asChild variant="outline" className="w-full justify-start">
                <Link href="/leaderboard">
                  <Trophy className="w-4 h-4 mr-2" />
                  Leaderboard
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
