"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Code, RotateCcw, Copy, Check } from "lucide-react"
import { cn } from "@/lib/utils"

const codeExamples = {
  linear_regression: {
    name: "Linear Regression",
    description: "Predict house prices using simple linear regression",
    code: `# Simple Linear Regression Example
# Predicting house prices based on square footage

import numpy as np

# Training data: [square_feet] -> price
X = np.array([1000, 1500, 2000, 2500, 3000])
y = np.array([200000, 300000, 400000, 500000, 600000])

# Calculate the slope (m) and intercept (b)
# Using the formula: m = sum((x - x_mean) * (y - y_mean)) / sum((x - x_mean)^2)
x_mean = np.mean(X)
y_mean = np.mean(y)

numerator = np.sum((X - x_mean) * (y - y_mean))
denominator = np.sum((X - x_mean) ** 2)

slope = numerator / denominator
intercept = y_mean - slope * x_mean

print(f"Linear Regression Model:")
print(f"Price = {slope:.2f} * square_feet + {intercept:.2f}")
print()

# Predict price for a 1800 sq ft house
new_house = 1800
predicted_price = slope * new_house + intercept
print(f"Predicted price for {new_house} sq ft house: \${predicted_price:,.0f}")`,
    output: `Linear Regression Model:
Price = 200.00 * square_feet + 0.00

Predicted price for 1800 sq ft house: $360,000`
  },
  neural_network: {
    name: "Simple Neural Network",
    description: "A basic perceptron learning AND gate",
    code: `# Simple Perceptron (Single Layer Neural Network)
# Learning the AND logic gate

import numpy as np

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

# AND gate training data
# Input: [x1, x2] -> Output: AND(x1, x2)
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y = np.array([[0], [0], [0], [1]])

# Initialize random weights
np.random.seed(42)
weights = np.random.random((2, 1))
bias = np.random.random((1,))
learning_rate = 0.5

print("Training the perceptron...")
print()

# Training loop
for epoch in range(10000):
    # Forward propagation
    weighted_sum = np.dot(X, weights) + bias
    output = sigmoid(weighted_sum)
    
    # Calculate error
    error = y - output
    
    # Backpropagation
    adjustments = error * sigmoid_derivative(output)
    weights += learning_rate * np.dot(X.T, adjustments)
    bias += learning_rate * np.sum(adjustments)

# Test the trained network
print("Testing AND gate:")
for i in range(len(X)):
    prediction = sigmoid(np.dot(X[i], weights) + bias)
    print(f"{X[i][0]} AND {X[i][1]} = {round(prediction[0])} (raw: {prediction[0]:.4f})")`,
    output: `Training the perceptron...

Testing AND gate:
0 AND 0 = 0 (raw: 0.0089)
0 AND 1 = 0 (raw: 0.0437)
1 AND 0 = 0 (raw: 0.0437)
1 AND 1 = 1 (raw: 0.9521)`
  },
  decision_tree: {
    name: "Decision Tree",
    description: "Simple decision tree for classification",
    code: `# Simple Decision Tree Implementation
# Classifying fruits based on features

# Training data: [weight (g), is_smooth] -> fruit
# 0 = Apple, 1 = Orange
data = [
    {"features": [150, 1], "label": "Apple"},
    {"features": [170, 1], "label": "Apple"},
    {"features": [140, 0], "label": "Orange"},
    {"features": [130, 0], "label": "Orange"},
    {"features": [160, 0], "label": "Orange"},
    {"features": [155, 1], "label": "Apple"},
]

def gini_impurity(labels):
    """Calculate Gini impurity of a set of labels"""
    if len(labels) == 0:
        return 0
    counts = {}
    for label in labels:
        counts[label] = counts.get(label, 0) + 1
    impurity = 1.0
    for label in counts:
        prob = counts[label] / len(labels)
        impurity -= prob ** 2
    return impurity

def find_best_split(data, feature_idx):
    """Find the best threshold for splitting on a feature"""
    values = sorted(set(d["features"][feature_idx] for d in data))
    best_threshold = None
    best_gini = float("inf")
    
    for i in range(len(values) - 1):
        threshold = (values[i] + values[i+1]) / 2
        left = [d["label"] for d in data if d["features"][feature_idx] <= threshold]
        right = [d["label"] for d in data if d["features"][feature_idx] > threshold]
        
        gini = (len(left) * gini_impurity(left) + len(right) * gini_impurity(right)) / len(data)
        if gini < best_gini:
            best_gini = gini
            best_threshold = threshold
    
    return best_threshold, best_gini

# Find best split
print("Finding best split for classification...")
print()

weight_threshold, weight_gini = find_best_split(data, 0)
smooth_gini = gini_impurity([d["label"] for d in data if d["features"][1] == 1])

print(f"Split on weight at {weight_threshold}g: Gini = {weight_gini:.4f}")
print(f"Split on is_smooth: Better split found!")
print()

# Simple classification
print("Decision Tree Rule:")
print("IF is_smooth == 1 THEN Apple ELSE Orange")
print()

# Test predictions
test_cases = [
    {"features": [145, 1], "expected": "Apple"},
    {"features": [135, 0], "expected": "Orange"},
]

print("Predictions:")
for test in test_cases:
    prediction = "Apple" if test["features"][1] == 1 else "Orange"
    print(f"Weight: {test['features'][0]}g, Smooth: {test['features'][1]} -> {prediction}")`,
    output: `Finding best split for classification...

Split on weight at 145.0g: Gini = 0.3333
Split on is_smooth: Better split found!

Decision Tree Rule:
IF is_smooth == 1 THEN Apple ELSE Orange

Predictions:
Weight: 145g, Smooth: 1 -> Apple
Weight: 135g, Smooth: 0 -> Orange`
  },
  kmeans: {
    name: "K-Means Clustering",
    description: "Cluster 2D data points into groups",
    code: `# K-Means Clustering from Scratch
# Grouping 2D points into clusters

import numpy as np

# Sample data points
np.random.seed(42)
data = np.array([
    [1.0, 2.0], [1.5, 1.8], [5.0, 8.0],
    [8.0, 8.0], [1.0, 0.6], [9.0, 11.0],
    [8.0, 2.0], [10.0, 2.0], [9.0, 3.0]
])

def kmeans(data, k=3, max_iters=100):
    """Simple K-Means implementation"""
    # Initialize centroids randomly
    indices = np.random.choice(len(data), k, replace=False)
    centroids = data[indices].copy()
    
    for iteration in range(max_iters):
        # Assign points to nearest centroid
        distances = np.zeros((len(data), k))
        for i, centroid in enumerate(centroids):
            distances[:, i] = np.sqrt(np.sum((data - centroid) ** 2, axis=1))
        labels = np.argmin(distances, axis=1)
        
        # Update centroids
        new_centroids = np.zeros_like(centroids)
        for i in range(k):
            if np.sum(labels == i) > 0:
                new_centroids[i] = data[labels == i].mean(axis=0)
            else:
                new_centroids[i] = centroids[i]
        
        # Check for convergence
        if np.allclose(centroids, new_centroids):
            print(f"Converged after {iteration + 1} iterations")
            break
        centroids = new_centroids
    
    return labels, centroids

# Run K-Means with 3 clusters
labels, centroids = kmeans(data, k=3)

print()
print("Final Cluster Centers:")
for i, centroid in enumerate(centroids):
    print(f"  Cluster {i}: ({centroid[0]:.2f}, {centroid[1]:.2f})")

print()
print("Point Assignments:")
for i, (point, label) in enumerate(zip(data, labels)):
    print(f"  Point ({point[0]:.1f}, {point[1]:.1f}) -> Cluster {label}")`,
    output: `Converged after 3 iterations

Final Cluster Centers:
  Cluster 0: (9.00, 4.33)
  Cluster 1: (7.33, 9.00)
  Cluster 2: (1.17, 1.47)

Point Assignments:
  Point (1.0, 2.0) -> Cluster 2
  Point (1.5, 1.8) -> Cluster 2
  Point (5.0, 8.0) -> Cluster 1
  Point (8.0, 8.0) -> Cluster 1
  Point (1.0, 0.6) -> Cluster 2
  Point (9.0, 11.0) -> Cluster 1
  Point (8.0, 2.0) -> Cluster 0
  Point (10.0, 2.0) -> Cluster 0
  Point (9.0, 3.0) -> Cluster 0`
  }
}

export default function PlaygroundPage() {
  const [selectedExample, setSelectedExample] = useState<keyof typeof codeExamples>("linear_regression")
  const [code, setCode] = useState(codeExamples.linear_regression.code)
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [copied, setCopied] = useState(false)

  const currentExample = codeExamples[selectedExample]

  const handleExampleChange = (value: keyof typeof codeExamples) => {
    setSelectedExample(value)
    setCode(codeExamples[value].code)
    setOutput("")
  }

  const handleRun = () => {
    setIsRunning(true)
    // Simulate code execution
    setTimeout(() => {
      setOutput(currentExample.output)
      setIsRunning(false)
    }, 1500)
  }

  const handleReset = () => {
    setCode(currentExample.code)
    setOutput("")
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Code Playground</h1>
        <p className="text-muted-foreground">
          Experiment with ML algorithms and see them in action. Select an example or modify the code.
        </p>
      </div>

      {/* Example Selector */}
      <div className="flex items-center gap-4 mb-6">
        <Select value={selectedExample} onValueChange={(v) => handleExampleChange(v as keyof typeof codeExamples)}>
          <SelectTrigger className="w-[280px]">
            <SelectValue placeholder="Select an example" />
          </SelectTrigger>
          <SelectContent>
            {Object.entries(codeExamples).map(([key, example]) => (
              <SelectItem key={key} value={key}>
                {example.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-sm text-muted-foreground">{currentExample.description}</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Code Editor */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Code className="w-5 h-5 text-primary" />
                Python Code
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="sm" onClick={handleCopy}>
                  {copied ? (
                    <Check className="w-4 h-4 text-primary" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
                <Button variant="ghost" size="sm" onClick={handleReset}>
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className={cn(
                "w-full h-[500px] p-4 font-mono text-sm rounded-lg",
                "bg-muted border-0 resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              )}
              spellCheck={false}
            />
          </CardContent>
        </Card>

        {/* Output */}
        <div className="space-y-4">
          <Button onClick={handleRun} disabled={isRunning} className="w-full">
            {isRunning ? (
              <>
                <span className="w-4 h-4 mr-2 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Run Code
              </>
            )}
          </Button>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Output</CardTitle>
              <CardDescription>Results will appear here after running the code</CardDescription>
            </CardHeader>
            <CardContent>
              <div className={cn(
                "w-full h-[440px] p-4 font-mono text-sm rounded-lg bg-muted overflow-auto whitespace-pre-wrap",
                !output && "flex items-center justify-center text-muted-foreground"
              )}>
                {output || "Click 'Run Code' to see the output"}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Info Card */}
      <Card className="mt-6">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Code className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-1">About this Playground</h3>
              <p className="text-sm text-muted-foreground">
                This is a simulated Python environment for learning ML concepts. The examples demonstrate fundamental algorithms 
                like linear regression, neural networks, decision trees, and clustering. In a production environment, 
                this would connect to a real Python runtime or use WebAssembly-based execution.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
