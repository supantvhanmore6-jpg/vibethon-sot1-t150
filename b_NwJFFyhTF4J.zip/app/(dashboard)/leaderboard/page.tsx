import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Trophy, Medal, Award, Zap, Target, Flame } from "lucide-react"
import { cn } from "@/lib/utils"

export default async function LeaderboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profiles } = await supabase
    .from("profiles")
    .select("id, display_name, email, xp_points, level, streak_days")
    .order("xp_points", { ascending: false })
    .limit(50)

  const userRank = profiles?.findIndex(p => p.id === user?.id) ?? -1

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 0:
        return <Trophy className="w-6 h-6 text-yellow-500" />
      case 1:
        return <Medal className="w-6 h-6 text-gray-400" />
      case 2:
        return <Award className="w-6 h-6 text-amber-600" />
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-sm font-bold text-muted-foreground">{rank + 1}</span>
    }
  }

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 0:
        return "bg-yellow-500/10 border-yellow-500/20"
      case 1:
        return "bg-gray-400/10 border-gray-400/20"
      case 2:
        return "bg-amber-600/10 border-amber-600/20"
      default:
        return ""
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Leaderboard</h1>
        <p className="text-muted-foreground">
          See how you rank among other learners. Complete lessons and quizzes to earn XP!
        </p>
      </div>

      {/* Your Rank */}
      {userRank >= 0 && (
        <Card className="mb-6 border-primary/50 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <span className="text-lg font-bold text-primary">#{userRank + 1}</span>
                </div>
                <div>
                  <p className="font-semibold text-foreground">Your Rank</p>
                  <p className="text-sm text-muted-foreground">
                    {profiles?.[userRank]?.xp_points || 0} XP total
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Level</p>
                  <p className="font-bold text-foreground">{profiles?.[userRank]?.level || 1}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Streak</p>
                  <p className="font-bold text-foreground flex items-center gap-1">
                    <Flame className="w-4 h-4 text-orange-500" />
                    {profiles?.[userRank]?.streak_days || 0}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Top 3 Podium */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        {/* Second Place */}
        {profiles?.[1] && (
          <Card className={cn("border", getRankBg(1))}>
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-2">
                {getRankIcon(1)}
              </div>
              <Avatar className="w-12 h-12 mx-auto mb-2">
                <AvatarFallback className="bg-gray-400/20 text-gray-500">
                  {(profiles[1].display_name || profiles[1].email || "U").slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <p className="font-medium text-foreground text-sm truncate">
                {profiles[1].display_name || profiles[1].email?.split("@")[0]}
              </p>
              <p className="text-sm text-muted-foreground">{profiles[1].xp_points} XP</p>
            </CardContent>
          </Card>
        )}

        {/* First Place */}
        {profiles?.[0] && (
          <Card className={cn("border -mt-4", getRankBg(0))}>
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-2">
                {getRankIcon(0)}
              </div>
              <Avatar className="w-14 h-14 mx-auto mb-2">
                <AvatarFallback className="bg-yellow-500/20 text-yellow-600">
                  {(profiles[0].display_name || profiles[0].email || "U").slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <p className="font-semibold text-foreground truncate">
                {profiles[0].display_name || profiles[0].email?.split("@")[0]}
              </p>
              <p className="text-sm text-muted-foreground">{profiles[0].xp_points} XP</p>
              <p className="text-xs text-primary mt-1">Level {profiles[0].level}</p>
            </CardContent>
          </Card>
        )}

        {/* Third Place */}
        {profiles?.[2] && (
          <Card className={cn("border", getRankBg(2))}>
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-2">
                {getRankIcon(2)}
              </div>
              <Avatar className="w-12 h-12 mx-auto mb-2">
                <AvatarFallback className="bg-amber-600/20 text-amber-600">
                  {(profiles[2].display_name || profiles[2].email || "U").slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <p className="font-medium text-foreground text-sm truncate">
                {profiles[2].display_name || profiles[2].email?.split("@")[0]}
              </p>
              <p className="text-sm text-muted-foreground">{profiles[2].xp_points} XP</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Full Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle>All Learners</CardTitle>
          <CardDescription>Top 50 learners by XP points</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {profiles?.slice(3).map((profile, index) => {
              const rank = index + 3
              const isCurrentUser = profile.id === user?.id

              return (
                <div
                  key={profile.id}
                  className={cn(
                    "flex items-center justify-between px-6 py-4",
                    isCurrentUser && "bg-primary/5"
                  )}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-8 flex justify-center">
                      {getRankIcon(rank)}
                    </div>
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className={cn(
                        "bg-primary/10 text-primary",
                        isCurrentUser && "bg-primary text-primary-foreground"
                      )}>
                        {(profile.display_name || profile.email || "U").slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className={cn(
                        "font-medium text-foreground",
                        isCurrentUser && "text-primary"
                      )}>
                        {profile.display_name || profile.email?.split("@")[0]}
                        {isCurrentUser && " (You)"}
                      </p>
                      <p className="text-sm text-muted-foreground">Level {profile.level}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Flame className="w-4 h-4 text-orange-500" />
                      {profile.streak_days}
                    </div>
                    <div className="flex items-center gap-1 font-medium text-primary">
                      <Zap className="w-4 h-4" />
                      {profile.xp_points}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
