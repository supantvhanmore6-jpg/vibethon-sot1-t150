import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Zap, Trophy, Target, Flame, BookOpen, FileQuestion, Calendar, CheckCircle2, Lock } from "lucide-react"
import { cn } from "@/lib/utils"

export default async function ProfilePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [
    { data: profile },
    { data: userProgress },
    { data: userBadges },
    { data: allBadges },
    { data: quizAttempts },
  ] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user!.id).single(),
    supabase.from("user_progress").select("*").eq("user_id", user!.id).eq("completed", true),
    supabase.from("user_badges").select("*, badges(*)").eq("user_id", user!.id),
    supabase.from("badges").select("*"),
    supabase.from("quiz_attempts").select("*").eq("user_id", user!.id),
  ])

  const displayName = profile?.display_name || user?.email?.split("@")[0] || "Learner"
  const initials = displayName.slice(0, 2).toUpperCase()
  
  const xpToNextLevel = 100
  const currentLevelXp = (profile?.xp_points || 0) % xpToNextLevel
  const progressToNextLevel = (currentLevelXp / xpToNextLevel) * 100

  const earnedBadgeIds = new Set(userBadges?.map(ub => ub.badge_id) || [])
  const quizzesPassed = quizAttempts?.filter(a => a.passed).length || 0
  const perfectQuizzes = quizAttempts?.filter(a => a.score === a.total_questions).length || 0

  const stats = [
    { label: "Total XP", value: profile?.xp_points || 0, icon: Zap, color: "text-primary" },
    { label: "Level", value: profile?.level || 1, icon: Target, color: "text-accent-foreground" },
    { label: "Streak", value: `${profile?.streak_days || 0} days`, icon: Flame, color: "text-orange-500" },
    { label: "Lessons", value: userProgress?.length || 0, icon: BookOpen, color: "text-primary" },
    { label: "Quizzes", value: quizzesPassed, icon: FileQuestion, color: "text-accent-foreground" },
    { label: "Badges", value: userBadges?.length || 0, icon: Trophy, color: "text-yellow-500" },
  ]

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Profile Header */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <Avatar className="w-24 h-24">
              <AvatarFallback className="bg-primary/10 text-primary text-2xl font-bold">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="text-center sm:text-left">
              <h1 className="text-2xl font-bold text-foreground">{displayName}</h1>
              <p className="text-muted-foreground">{user?.email}</p>
              <div className="flex items-center justify-center sm:justify-start gap-4 mt-2">
                <span className="text-sm text-muted-foreground flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Joined {new Date(profile?.created_at || Date.now()).toLocaleDateString()}
                </span>
              </div>
            </div>
            <div className="sm:ml-auto flex flex-col items-center p-4 rounded-lg bg-primary/5">
              <span className="text-3xl font-bold text-primary">Level {profile?.level || 1}</span>
              <div className="w-40 mt-2">
                <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                  <span>{currentLevelXp} XP</span>
                  <span>{xpToNextLevel} XP</span>
                </div>
                <Progress value={progressToNextLevel} className="h-2" />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4 text-center">
              <stat.icon className={cn("w-6 h-6 mx-auto mb-2", stat.color)} />
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Badges Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Badges
          </CardTitle>
          <CardDescription>
            {userBadges?.length || 0} of {allBadges?.length || 0} badges earned
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {allBadges?.map((badge) => {
              const isEarned = earnedBadgeIds.has(badge.id)
              const earnedBadge = userBadges?.find(ub => ub.badge_id === badge.id)

              return (
                <div
                  key={badge.id}
                  className={cn(
                    "flex items-center gap-3 p-4 rounded-lg border",
                    isEarned 
                      ? "bg-primary/5 border-primary/20" 
                      : "bg-muted/50 border-border opacity-60"
                  )}
                >
                  <div className={cn(
                    "w-12 h-12 rounded-full flex items-center justify-center",
                    isEarned ? "bg-primary/10" : "bg-muted"
                  )}>
                    {isEarned ? (
                      <Trophy className={cn(
                        "w-6 h-6",
                        badge.name.includes("Gold") ? "text-yellow-500" :
                        badge.name.includes("Silver") ? "text-gray-400" :
                        badge.name.includes("Bronze") ? "text-amber-600" :
                        "text-primary"
                      )} />
                    ) : (
                      <Lock className="w-5 h-5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={cn(
                      "font-medium truncate",
                      isEarned ? "text-foreground" : "text-muted-foreground"
                    )}>
                      {badge.name}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {badge.description}
                    </p>
                    {isEarned && earnedBadge && (
                      <p className="text-xs text-primary mt-1 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        Earned {new Date(earnedBadge.earned_at).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
