import { createClient } from "@/lib/supabase/server"
import { notFound, redirect } from "next/navigation"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { QuizClient } from "@/components/quiz/quiz-client"

interface QuizPageProps {
  params: Promise<{ moduleId: string }>
}

export default async function QuizPage({ params }: QuizPageProps) {
  const { moduleId } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [
    { data: module },
    { data: quiz },
    { data: lessons },
    { data: userProgress },
  ] = await Promise.all([
    supabase.from("modules").select("*").eq("id", moduleId).single(),
    supabase.from("quizzes").select("*").eq("module_id", moduleId).single(),
    supabase.from("lessons").select("id").eq("module_id", moduleId),
    supabase.from("user_progress").select("lesson_id, completed").eq("user_id", user!.id).eq("completed", true),
  ])

  if (!module || !quiz) {
    notFound()
  }

  // Check if all lessons are completed
  const completedLessonIds = new Set(userProgress?.map(p => p.lesson_id) || [])
  const allLessonsCompleted = lessons?.every(l => completedLessonIds.has(l.id))

  if (!allLessonsCompleted) {
    redirect(`/modules/${moduleId}`)
  }

  const { data: questions } = await supabase
    .from("quiz_questions")
    .select("*")
    .eq("quiz_id", quiz.id)
    .order("order_index")

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link 
        href={`/modules/${moduleId}`}
        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to {module.title}
      </Link>

      <QuizClient 
        quiz={quiz} 
        questions={questions || []} 
        moduleId={moduleId}
        moduleName={module.title}
      />
    </div>
  )
}
