import { createClient } from "@/lib/supabase/server"
import { notFound } from "next/navigation"
import Link from "next/link"
import { ArrowLeft, ArrowRight, CheckCircle2, Zap } from "lucide-react"
import { LessonContent } from "@/components/lessons/lesson-content"
import { CompleteLessonButton } from "@/components/lessons/complete-lesson-button"
import { Button } from "@/components/ui/button"

interface LessonPageProps {
  params: Promise<{ moduleId: string; lessonId: string }>
}

export default async function LessonPage({ params }: LessonPageProps) {
  const { moduleId, lessonId } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [
    { data: lesson },
    { data: module },
    { data: allLessons },
    { data: userProgress },
  ] = await Promise.all([
    supabase.from("lessons").select("*").eq("id", lessonId).single(),
    supabase.from("modules").select("*").eq("id", moduleId).single(),
    supabase.from("lessons").select("*").eq("module_id", moduleId).order("order_index"),
    supabase.from("user_progress").select("*").eq("user_id", user!.id).eq("lesson_id", lessonId).single(),
  ])

  if (!lesson || !module) {
    notFound()
  }

  const currentIndex = allLessons?.findIndex(l => l.id === lessonId) ?? 0
  const prevLesson = currentIndex > 0 ? allLessons?.[currentIndex - 1] : null
  const nextLesson = currentIndex < (allLessons?.length || 0) - 1 ? allLessons?.[currentIndex + 1] : null
  const isCompleted = userProgress?.completed || false

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <Link 
          href={`/modules/${moduleId}`}
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to {module.title}
        </Link>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">
              Lesson {currentIndex + 1} of {allLessons?.length || 0}
            </p>
            <h1 className="text-2xl font-bold text-foreground">{lesson.title}</h1>
          </div>
          {isCompleted && (
            <div className="flex items-center gap-2 text-primary">
              <CheckCircle2 className="w-5 h-5" />
              <span className="font-medium">Completed</span>
            </div>
          )}
        </div>
      </div>

      {/* Lesson Content */}
      <div className="bg-card border border-border rounded-lg p-6 md:p-8 mb-8">
        <LessonContent content={lesson.content} />
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-card border border-border rounded-lg">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Zap className="w-4 h-4 text-primary" />
          <span className="text-sm">Earn {lesson.xp_reward} XP by completing this lesson</span>
        </div>
        
        {!isCompleted && (
          <CompleteLessonButton 
            lessonId={lessonId} 
            xpReward={lesson.xp_reward}
            nextLessonUrl={nextLesson ? `/modules/${moduleId}/lessons/${nextLesson.id}` : `/modules/${moduleId}`}
          />
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between mt-6">
        {prevLesson ? (
          <Button asChild variant="outline">
            <Link href={`/modules/${moduleId}/lessons/${prevLesson.id}`}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Previous
            </Link>
          </Button>
        ) : (
          <div />
        )}
        
        {nextLesson ? (
          <Button asChild variant="outline">
            <Link href={`/modules/${moduleId}/lessons/${nextLesson.id}`}>
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
        ) : (
          <Button asChild>
            <Link href={`/modules/${moduleId}`}>
              Back to Module
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
        )}
      </div>
    </div>
  )
}
