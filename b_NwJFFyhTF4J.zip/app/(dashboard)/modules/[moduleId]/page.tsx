import { createClient } from "@/lib/supabase/server"
import { notFound } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { ArrowLeft, BookOpen, Clock, CheckCircle2, Circle, Play, FileQuestion } from "lucide-react"

interface ModulePageProps {
  params: Promise<{ moduleId: string }>
}

export default async function ModulePage({ params }: ModulePageProps) {
  const { moduleId } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [
    { data: module },
    { data: lessons },
    { data: userProgress },
    { data: quiz },
  ] = await Promise.all([
    supabase.from("modules").select("*").eq("id", moduleId).single(),
    supabase.from("lessons").select("*").eq("module_id", moduleId).order("order_index"),
    supabase.from("user_progress").select("lesson_id, completed").eq("user_id", user!.id),
    supabase.from("quizzes").select("*").eq("module_id", moduleId).single(),
  ])

  if (!module) {
    notFound()
  }

  const completedLessonIds = new Set(
    userProgress?.filter(p => p.completed).map(p => p.lesson_id) || []
  )

  const allLessonsCompleted = lessons?.every(l => completedLessonIds.has(l.id))

  // Find first incomplete lesson
  const firstIncompleteLessonIndex = lessons?.findIndex(l => !completedLessonIds.has(l.id)) ?? -1

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back button */}
      <Link 
        href="/modules" 
        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Modules
      </Link>

      {/* Module Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <h1 className="text-3xl font-bold text-foreground">{module.title}</h1>
          <Badge variant={
            module.difficulty === "beginner" ? "default" :
            module.difficulty === "intermediate" ? "secondary" :
            "outline"
          } className="capitalize">
            {module.difficulty}
          </Badge>
        </div>
        <p className="text-muted-foreground">{module.description}</p>
        <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <BookOpen className="w-4 h-4" />
            <span>{lessons?.length || 0} lessons</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>~{module.estimated_minutes} min</span>
          </div>
        </div>
      </div>

      {/* Lessons List */}
      <div className="space-y-3 mb-8">
        <h2 className="text-lg font-semibold text-foreground mb-4">Lessons</h2>
        {lessons?.map((lesson, index) => {
          const isCompleted = completedLessonIds.has(lesson.id)
          const isNext = index === firstIncompleteLessonIndex

          return (
            <Link key={lesson.id} href={`/modules/${moduleId}/lessons/${lesson.id}`}>
              <Card className={`transition-all hover:border-primary/50 ${isNext ? "border-primary/50 bg-primary/5" : ""}`}>
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted 
                        ? "bg-primary/10 text-primary" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <span className="text-sm font-medium">{index + 1}</span>
                      )}
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">{lesson.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        <span>~5 min</span>
                        <span className="text-primary">+{lesson.xp_reward} XP</span>
                      </div>
                    </div>
                  </div>
                  {isNext && (
                    <Button size="sm">
                      <Play className="w-4 h-4 mr-1" />
                      Start
                    </Button>
                  )}
                  {isCompleted && (
                    <span className="text-sm text-primary font-medium">Completed</span>
                  )}
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>

      {/* Quiz Section */}
      {quiz && (
        <Card className={`${allLessonsCompleted ? "border-primary/50" : "opacity-60"}`}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <FileQuestion className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">{quiz.title}</h3>
                  <p className="text-sm text-muted-foreground">{quiz.description}</p>
                  <p className="text-sm text-primary mt-1">+{quiz.xp_reward} XP</p>
                </div>
              </div>
              {allLessonsCompleted ? (
                <Button asChild>
                  <Link href={`/modules/${moduleId}/quiz`}>
                    Take Quiz
                  </Link>
                </Button>
              ) : (
                <Button disabled variant="outline">
                  Complete lessons first
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
