import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { BookOpen, Clock, CheckCircle2, Lock, Brain, Cpu, Network, Layers } from "lucide-react"

const moduleIcons: Record<string, React.ElementType> = {
  brain: Brain,
  cpu: Cpu,
  network: Network,
  layers: Layers,
}

export default async function ModulesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [
    { data: modules },
    { data: userProgress },
  ] = await Promise.all([
    supabase
      .from("modules")
      .select("*, lessons(id)")
      .order("order_index"),
    supabase
      .from("user_progress")
      .select("lesson_id, completed, lessons(module_id)")
      .eq("user_id", user!.id)
      .eq("completed", true),
  ])

  const completedByModule = new Map<string, number>()
  userProgress?.forEach(p => {
    const moduleId = p.lessons?.module_id
    if (moduleId) {
      completedByModule.set(moduleId, (completedByModule.get(moduleId) || 0) + 1)
    }
  })

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground mb-2">Learning Modules</h1>
        <p className="text-muted-foreground">
          Progress through structured modules to master AI and Machine Learning.
        </p>
      </div>

      <div className="space-y-4">
        {modules?.map((module, index) => {
          const lessonCount = module.lessons?.length || 0
          const completedCount = completedByModule.get(module.id) || 0
          const progressPercent = lessonCount > 0 ? Math.round((completedCount / lessonCount) * 100) : 0
          const isCompleted = completedCount === lessonCount && lessonCount > 0
          const IconComponent = moduleIcons[module.icon || "brain"] || BookOpen

          // Check if previous module is completed (for locking)
          const prevModule = modules[index - 1]
          const prevModuleCompleted = !prevModule || 
            (completedByModule.get(prevModule.id) || 0) === (prevModule.lessons?.length || 0)
          const isLocked = index > 0 && !prevModuleCompleted

          return (
            <Link 
              key={module.id} 
              href={isLocked ? "#" : `/modules/${module.id}`}
              className={isLocked ? "cursor-not-allowed" : ""}
            >
              <Card className={`transition-all ${isLocked ? "opacity-60" : "hover:border-primary/50 hover:shadow-md"}`}>
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center shrink-0 ${
                      isCompleted 
                        ? "bg-primary/10" 
                        : isLocked 
                        ? "bg-muted" 
                        : "bg-primary/10"
                    }`}>
                      {isLocked ? (
                        <Lock className="w-6 h-6 text-muted-foreground" />
                      ) : isCompleted ? (
                        <CheckCircle2 className="w-6 h-6 text-primary" />
                      ) : (
                        <IconComponent className="w-6 h-6 text-primary" />
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg text-foreground">{module.title}</h3>
                        <Badge variant={
                          module.difficulty === "beginner" ? "default" :
                          module.difficulty === "intermediate" ? "secondary" :
                          "outline"
                        } className="capitalize">
                          {module.difficulty}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground text-sm mb-4">{module.description}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                        <div className="flex items-center gap-1">
                          <BookOpen className="w-4 h-4" />
                          <span>{lessonCount} lessons</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>~{module.estimated_minutes} min</span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium text-foreground">{completedCount}/{lessonCount}</span>
                        </div>
                        <Progress value={progressPercent} className="h-2" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
