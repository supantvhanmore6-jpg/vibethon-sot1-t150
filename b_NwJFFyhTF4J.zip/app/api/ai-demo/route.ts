import {
  consumeStream,
  convertToModelMessages,
  streamText,
  UIMessage,
} from 'ai'

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages }: { messages: UIMessage[] } = await req.json()

  const result = streamText({
    model: 'openai/gpt-5-mini',
    system: `You are an AI/ML teaching assistant helping users understand artificial intelligence and machine learning concepts. 
    
Your role is to:
- Explain AI/ML concepts in simple, beginner-friendly terms
- Provide real-world examples and analogies
- Answer questions about neural networks, machine learning algorithms, deep learning, etc.
- Help users understand the practical applications of AI
- Be encouraging and supportive of learners at all levels

Keep responses concise but informative. Use markdown formatting for code examples and bullet points when helpful.`,
    messages: await convertToModelMessages(messages),
    abortSignal: req.signal,
  })

  return result.toUIMessageStreamResponse({
    originalMessages: messages,
    consumeSseStream: consumeStream,
  })
}
